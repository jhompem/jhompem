<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Add FAQ's</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Add FAQ's</li>
                        </ol>
                        <div class="row">
                        <?php include('message.php'); ?>
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Add FAQ's<a href="list-faqs.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                        <form action="function.php" method="POST">
                                                <div class="row">
                                                     <div class="col-xl-6 col-md-6">
                                                         <label for="">Question</label>
                                                         <input type="text" name="Question" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
                                                     </div>
                                                     <div class="col-xl-9 col-md-6">
                                                         <label for="">Answer</label>
                                                         <textarea name="Answer" class="form-control" minlength="2" maxlength ="500" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required></textarea>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6">
</br>
                                                        <button type="submit" name="btnfaqs" class="btn btn-primary"><i class="fas fa-save"></i> Add FAQ's</button>
                                                     </div>
                                                </div>
                                            </form>
                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>