<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Add Category</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Add Category</li>
                        </ol>
                        <div class="row">
                        <?php include('message.php'); ?>
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Add Category<a href="category.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                        <form action="function.php" method="POST">
                                                <div class="row">
                                                    <Strong><label for="" class="mb-4">Category</label></Strong>
                                                    <div class="col-xl-3 col-md-6">
                                                         <label for="">Category Name</label>
                                                         <input type="text" name="CatName" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6">
</br>
                                                         <button type="submit" name="btncatadd" class="btn btn-primary"><i class="fas fa-save"></i> Add Category</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php 
                                                $CData=mysqli_query($con,"SELECT * FROM category");
                                            ?>

                                            <form action="function.php" method="POST">
                                                <div class="row">
                                                    <Strong><label for="" class="mt-4">Sub Category</label></Strong>
                                                    <div class="col-xl-3 col-md-6">
                                                         <label for="">Category Name</label>
                                                         <select name="CatID" id="" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
                                                            <option value="0">--Select Category Name--</option>
                                                             <?php
                                                             while($CGet = mysqli_fetch_array($CData))
                                                             {  
                                                                 ?>
                                                                     <option value="<?php echo $CGet['CatID']; ?>"><?php echo $CGet['CatName']; ?></option>
                                                                 <?php
                                                            }
                                                             ?>
                                                         </select>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">SubCategory Name</label>
                                                         <input type="text" name="SubCatName" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6">
</br>
                                                         <button type="submit" name="btnsubcatadd" class="btn btn-primary"><i class="fas fa-save"></i> Add SubCategory</button>
                                                     </div>
                                                </div>
                                            </form>

                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>