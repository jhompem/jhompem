<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Add New Ordinance</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Add New Ordinance</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-md-12">
                            <?php include('message.php'); ?>
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Add New Ordinance 
                                            <a href="list-ordinance.php"><i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                              
                                            <form action="function.php" method="POST" enctype="multipart/form-data">
                                                <div class="row">
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Ordinance Number</label>
                                                         <input type="text" name="OrdinanceNo" class="form-control" required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Ordinance Title</label>
                                                         <input type="text" name="Title" class="form-control" required>
                                                     </div>
                                                     <div class="col-xl-6 col-md-12">
                                                    </div>
                                                     
                                                     <div class="col-xl-9 col-md-6">
                                                     </div>
                                                     <div class="col-xl-6 col-md-6">
                                                     <label for="">Description</label>
                                                         <textarea  name="Description" cols="30" rows="5" class="form-control" required></textarea>
                                                     </div>
                                                     <div class="col-xl-6 col-md-6">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                     <label for="">Upload image</label>
                                                         <input type="file" name="Image" class="form-control" required>
                                                         <br>
                                                         <button type="submit" name="btnordiadd" class="btn btn-primary mt-4" ><i class="fas fa-save"></i> Add Ordinance</button>
                                                     </div>
                                                </div>
                                            </form>
                                            
                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>