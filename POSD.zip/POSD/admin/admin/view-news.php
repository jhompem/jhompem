<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Post Details</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Post Details</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-md-12">
                            <?php include('message.php'); ?>
                                <div class="card">
                                    <div class="card-header">
                                    <?php
                                            if(isset($_GET['id']))
                                            {
                                                
                                                $NewsID = $_GET['id'];
                                                ?>
                                        <h4>Post Details 
                                            <a href="list-news.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                           
                                                <?php
                                                $CDetails = "SELECT * FROM news WHERE NewsID='$NewsID' LIMIT 1";
                                                $CDetails_run = mysqli_query($con, $CDetails);
                                                if(mysqli_num_rows($CDetails_run) > 0)
                                                {    
                                                    $Detailsrow = mysqli_fetch_array($CDetails_run);
                                                    ?>
                                            <form action="../allcode.php" method="POST" enctype="multipart/form-data">
                                                <div class="row">
                                                <div class="col-xl-3 col-md-6">
                                                         <input type="hidden" name="NewsID" value="<?=$Detailsrow['NewsID'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-9 col-md-12">
                                                    </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Post Title</label>
                                                         <input type="text" name="Title" value="<?=$Detailsrow['Title'];?>" class="form-control" required>
                                                     </div>
                                                     
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Complaint Status</label>
                                                         <select name="Status" class="form-control" required>
                                                            <option value="">--Select Status--</option>
                                                            <option value="0" <?= $Detailsrow['status'] == '0' ? 'selected':'' ?>>Posted</option>
                                                            <option value="1" <?= $Detailsrow['status'] == '1' ? 'selected':'' ?>>Unposted</option>
                                                         </select>
                                                     </div>
                                                     <div class="col-xl-6 col-md-6">
                                                     </div>
                                                     
                                                     <div class="col-xl-3 col-md-6"><br>
                                                         <input type="hidden" name="OldFileName" value="<?=$Detailsrow['Image'];?>">
                                                         <img src="../../assets/news/<?= $Detailsrow['Image']; ?>" width="250px" height="160px">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                     <label for="">If you need to change image</label>
                                                         <input type="file" name="Image" class="form-control">
                                                         <br>
                                                         <button type="submit" name="btnnewsupdate" class="btn btn-primary mt-4 float-end" ><i class="fas fa-save"></i> Update</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>