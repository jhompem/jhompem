<?php
include('authentication.php');
include('midleware/sadminauth.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Case History</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Case History</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-xl-12">
                                <?php include('message.php'); ?>
                                <div class="card">
                                    <div class="card-header">
                                    <?php
                                                    if(isset($_GET['id']))
                                                    {
                                                    $CaseNo = $_GET['id'];
                                                    ?>
                                        <h4>Case History
                                        <a href="view-complaint.php?id=<?php echo $CaseNo; ?>"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                       </div>
                                        <div class="card-body">    
                                          <div class="table-resposive">
                                         <table class="table table-bordered mt-4">
                                                <thead>
                                                    <tr>
                                                        <th>Case No</th>
                                                        <th>Message to</th>
                                                        <th>Subject</th>
                                                        <th>Purpose</th>
                                                        <th>Date Sent</th>
                                                        <th>Function</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $query = "SELECT * FROM message WHERE CaseNO =$CaseNo ORDER BY DateSent DESC";
                                                    $query_run = mysqli_query($con, $query);

                                                    if(mysqli_num_rows($query_run) > 0)
                                                    {

                                                        foreach($query_run as $row)
                                                        {
                                                            $timestamp = $row['DateSent'];
                                                            ?>
                                                    <tr>
                                                        <td><?= $row['CaseNo'];?></td>
                                                        <td><?= $row['Mto']; ?></td>
                                                        <td><?= $row['MSubject']; ?></td>
                                                        <td><?= $row['Purpose']; ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($timestamp)); ?></td>
                                                        <td>
                                                            <a href="view-chistory.php?id=<?= $row['MessageID'];?>" class="btn btn-success"><i class="fas fa-eye"></i> View</a>
                                                        </td>
                                                    </tr>

                                                            <?php
                                                        }

                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        <td colspan="4">No Record Found</td>
                                                        <?php
                                                    }
                                                }

                                                    ?>
                                                    
                                                </tbody>
                                            </table>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>