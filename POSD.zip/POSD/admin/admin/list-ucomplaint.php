<?php
include('authentication.php');
include('midleware/sadminauth.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Undefined Complaint List</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Undefined Complaint List</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-xl-12">
                                <?php include('message.php'); ?>
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Undefined Complaint List
                                            <a href="index.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                       </div>
                                        <div class="card-body">
                                        <div class="table-responsive">
                                         <table id="tblucomp" class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Case No</th>
                                                        <th>First Name</th>
                                                        <th>Last Name</th>
                                                        <th>Date of Complaint</th>
                                                        <th>Officer In Charge</th>
                                                        <th>Date Respond</th>
                                                        <th>Status</th>
                                                        <th>View</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $query = "SELECT * FROM complain WHERE Status ='1'";
                                                    $query_run = mysqli_query($con, $query);

                                                    if(mysqli_num_rows($query_run) > 0)
                                                    {

                                                        foreach($query_run as $row)
                                                        {
                                                            $timestamp = $row['DateComplained'];
                                                            $timestamp1 = $row['DateRespond'];
                                                            ?>

                                                    <tr>
                                                        <td><?= $row['CaseNo']; ?></td>
                                                        <td><?= $row['CFirstName']; ?></td>
                                                        <td><?= $row['CLastName']; ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($timestamp)); ?></td>
                                                        <td><?= $row['ROfficer']; ?></td>
                                                        <td>
                                                            <?php 
                                                            if(empty($timestamp1))
                                                            {
                                                                $timestamp1 = '';
                                                            }
                                                            else
                                                            {
                                                            echo date('M d, Y', strtotime($timestamp1)); 
                                                            }
                                                            ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                            if($row['Status'] == '2')
                                                            {
                                                                echo 'Open';
                                                            }
                                                            elseif ($row['Status'] == '3')
                                                            {
                                                                echo 'Closed';
                                                            }
                                                            else
                                                            {
                                                                echo 'Undifined';
                                                            }
                                                            ?>
                                                            
                                                        </td>
                                                        <td>
                                                        <a href="view-ucomplaint.php?id=<?=$row['CaseID'];?>" class="btn btn-success"><i class="fas fa-eye"></i></a>
                                                        </td>
                                                    </tr>

                                                            <?php
                                                        }

                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        <td colspan="8">No Record Found</td>
                                                        <?php
                                                    }

                                                    ?>
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>