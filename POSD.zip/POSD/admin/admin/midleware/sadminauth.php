<?php

if( $_SESSION['auth_role'] != "2" && $_SESSION['auth_role'] != "0")
{
    $_SESSION['message'] = "You are not Authorized to access super admin page";
    header("Location: index.php");
    exit(0);

}


?>