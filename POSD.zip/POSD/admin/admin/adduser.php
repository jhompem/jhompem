<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Add Users</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Add User</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Add User<a href="view-register.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                        <form action="function.php" method="POST">
                                                <div class="row">
                                                    <div class="col-xl-3 col-md-6">
                                                         <label for="">First Name</label>
                                                         <input type="text" name="FirstName" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Last Name</label>
                                                         <input type="text" name="LastName" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field" required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Address</label>
                                                         <input type="text" name="Address" class="form-control" minlength="2" pattern="^[a-zA-Z\d\s]+" title="Please do not add any symbol" required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Email</label>
                                                         <input type="email" name="Email" class="form-control" minlength="2" pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$" title = "Please input a valid email format eg. cauayan@isabela.com" required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Phone Number</label>
                                                         <input type="text" name="Mobile" class="form-control" pattern="^[+]?[\d]+([\-][\d]+)*\d$" minlength="11" title="Must start with [09 / +63] and at least 11 digit number to 13 with area code" required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Password</label>
                                                         <input type="password" name="Password" class="form-control" minlength="8" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number [1-0] and one uppercase [A-Z] and lowercase [a-z] letter and one symbol [*!#], and at least 8 or more characters" required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">User Level</label>
                                                         <select name="UserLevel" id=""class="form-control" required>
                                                            <option value="">--Select Role--</option>
                                                            <option value="0">Admin</option>
                                                            <option value="1">User</option>
                                                            <option value="2">Super Admin</option>
                                                         </select>
                                                     </div>
                                                     <div class="col-md-12 ">
                                                        </br>
                                                         <button type="submit" name="btnadd" class="btn btn-primary"><i class="fas fa-user-plus"></i> Add User</button>
                                                     </div>
                                                </div>
                                            </form>

                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>