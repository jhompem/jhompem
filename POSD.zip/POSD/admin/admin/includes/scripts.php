        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></>
        <script src="js/datatables-simple-demo.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
        <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script>

$(document).ready( function () {
$('#tblfaqs').DataTable();
} );
$(document).ready( function () {
$('#tblusers').DataTable();
} );
$(document).ready( function () {
$('#tblcomp').DataTable();
} );
$(document).ready( function () {
$('#tblucomp').DataTable();
} );
$(document).ready( function () {
$('#tblnews').DataTable();
} );
$(document).ready( function () {
$('#tblcc').DataTable();
} );
$(document).ready( function () {
$('#tblmsg').DataTable();
} );
</script>


</body>
</html>