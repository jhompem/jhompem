                    <section>
                    <div class="div modal fade" id="reg-modal" tabindex="-1" aria-labelledby="modal-title" aria-hedden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modal-title">Complaint Proof</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row justify-content-center">
                                    <?php
                                if(isset($_GET['id']))
                                            {
                                                
                                                $CaseNo = $_GET['id'];
                                                $CDetails = "SELECT * FROM complain WHERE CaseNo='$CaseNo' ";
                                                $CDetails_run = mysqli_query($con, $CDetails);
                                                if(mysqli_num_rows($CDetails_run) > 0)
                                                {    
                                                    foreach($CDetails_run as $Details)
                                                    {
                                                ?>
                                                <img src="../../assets/proof/<?=$Details['CProof'];?>" class="img-fluid">
                                                <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>

                                </div>
                                </div>
                                <div class="div modal-footer">

                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; PCMS|POSD <?php $year = date("Y"); echo $year;?></div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
                
            </div>
        </div>