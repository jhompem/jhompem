
<div id="layoutSidenav_nav">
                
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Admin Panel</div>
                            <a class="nav-link" href="index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <?php if($_SESSION['auth_role'] == '2') : ?>
                            <a class="nav-link" href="view-register.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                                Registered User
                            </a>
                            <?php endif; ?>
                            <div class="sb-sidenav-menu-heading">Client</div>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Complaint Logs
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="list-complaint.php">Complaints</a>
                                    <a class="nav-link" href="list-ucomplaint.php">Undefined Complaints</a>
                                </nav>
                            </div>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages">
                                <div class="sb-nav-link-icon"><i class="fa fa-chart-bar"></i></div>
                                Statistical Reports
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    <a class="nav-link collapsed" href="rdaily.php">Daily</a>
                                    <a class="nav-link collapsed" href="rweekly.php">Weekly</a>
                                    <a class="nav-link collapsed" href="rmonthly.php">Monthly</a>
                                </nav>
                            </div>
                            <?php if($_SESSION['auth_role'] == '2') : ?>
                            <div class="sb-sidenav-menu-heading">Interface</div>
                            
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#frontend" aria-expanded="false" aria-controls="frontend">
                                <div class="sb-nav-link-icon"><i class="fas fa-universal-access"></i></div>
                                Frontend
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="frontend" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="list-news.php">Post News</a>
                                    <a class="nav-link" href="list-ordinance.php">Ordinance</a>
                                    <a class="nav-link" href="list-faqs.php">FAQ's</a>
                                </nav>
                            </div>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#Backend" aria-expanded="false" aria-controls="Backend">
                                <div class="sb-nav-link-icon"><i class="fas fa-door-closed"></i></div>
                                Backend
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            
                            <div class="collapse" id="Backend" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="category.php">Complaint Category</a>
                                    <a class="nav-link" href="view-dbbackup.php">Backup & Restore</a>
                                </nav>
                            </div>
                            <?php endif; ?>
                            <div class="sb-sidenav-menu-heading">Message</div>
                            <a class="nav-link" href="view-sent.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-paper-plane"></i></div>
                                Message Sent
                            </a>
                        </div>
                        
                    </div>

                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        <?= $_SESSION['auth_user']['UFullName']; ?>
                    </div>
                </nav>
            </div>