<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Send Email</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Send Email</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Send Email<a href="view-sent.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                        <form action="function.php" method="POST">
                                                <div class="row">
                                                <div class="col-xl-3 col-md-6">
                                                         <label for="">Case No</label>
                                                         <input type="text" name="CaseNo" class="form-control">
                                                     </div>
                                                     <div class="col-xl-6 col-md-6">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Purpose of Email</label>
                                                         <input type="text" name="Purpose" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">From</label>
                                                         <input type="text" name="MFrom" class="form-control" value="cauayanposd@gmail.com" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">To</label>
                                                         <input type="text" name="Mto" class="form-control" minlength="2" pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$" title = "Please input a valid email format eg. cauayan@isabela.com" required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Subject</label>
                                                         <input type="text" name="MSubject" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">User Sender</label>
                                                         <input type="text" name="Sender" class="form-control" value="<?= $_SESSION['auth_user']['UFullName']; ?>" readonly>
                                                         <label name="SenderID"for=""hidden><?= $_SESSION['auth_user']['UserID']; ?></label>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6 mt-3">
                                                         <hr>
                                                     </div>
                                                     
                                                     <div class="col-xl-12 col-md-6">
                                                         <label for="">Email Body</label>
                                                        <textarea name="MBody" id="" cols="30" rows="5" class="form-control"></textarea>
                                                     </div>
                                                     <div class="col-md-12 ">
                                                        </br>
                                                         <button type="submit" name="btnsendmail" class="btn btn-primary float-end"><i class="fas fa-paper-plane"></i> Send Email</button>
                                                     </div>
                                                </div>
                                            </form>

                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>