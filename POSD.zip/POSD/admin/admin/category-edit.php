<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Edit Category</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Edit Category</li>
                        </ol>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Edit Category<a href="category.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                        <?php
                                            if(isset($_GET['id']))
                                            {
                                                $cat_id = $_GET['id'];
                                                $Cat = "SELECT * FROM category WHERE CatID='$cat_id' ";
                                                $Cat_run = mysqli_query($con, $Cat);
                                                if(mysqli_num_rows($Cat_run) > 0)
                                                {
                                                    foreach($Cat_run as $CatNew)
                                                    {
                                                    ?>
                                        <form action="function.php" method="POST">
                                            <input type="hidden" name="CatID" value="<?=$CatNew['CatID'];?>" class="form-control">
                                                 <div class="row">
                                                    <Strong><label for="" class="mb-4">Category</label></Strong>
                                                    <div class="col-xl-3 col-md-6">
                                                         <label for="">Category Name</label>
                                                         <input type="text" name="CatName" value="<?=$CatNew['CatName'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-12 col-md-6">
                                                    </br>
                                                         <button type="submit" name="btncatupdate" class="btn btn-primary"><i class="fas fa-save"></i> Update Category</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>
                                            
                                            <?php
                                            if(isset($_GET['subid']))
                                            {
                                            $SubCatID = $_GET['subid'];
                                            $subcatedit = "SELECT * FROM subcategory where SubID = $SubCatID LIMIT 1";
                                            $subcat_run = mysqli_query($con, $subcatedit);
                                            
                                                if(mysqli_num_rows($subcat_run) > 0)
                                                {
                                                    $crow = mysqli_fetch_array($subcat_run);
                                                    ?>
                                                    
                                            <form action="function.php" method="POST">
                                            <input name="SubID" type="hidden" value="<?= $crow['SubID']?>">
                                            <input name="CCatID" type="hidden" value="<?= $crow['CatID']?>">
                                                <div class="row">
                                                    <Strong><label for="" class="mt-4">Sub Category</label></Strong>
                                                    <div class="col-xl-3 col-md-6">
                                                         <label for="">Category Name</label>

                                                         <?php
                                                         $GetCat = "SELECT * FROM category";
                                                         $GetCat_run = mysqli_query($con, $GetCat);
                                                         if(mysqli_num_rows($GetCat_run) > 0)
                                                         {
                                                             ?>
                                                           
                                                         <select name="CatID" id="" class="form-control" require>
                                                            <option value="0">--Select Category Name--</option>
                                                            <?php
                                                            foreach($GetCat_run as $CatName)
                                                            {
                                                                ?>
                                                                 <option value="<?= $CatName['CatID'] ?>" <?= $CatName['CatID'] == $crow['CatID'] ? 'selected':'' ?>>
                                                                 <?= $CatName['CatName'] ?>
                                                                </option>
                                                                 <?php
                                                            }
                                                            ?>
                                                         </select>
                                                         <?php
                                                         }
                                                         else
                                                         {
                                                             ?>
                                                             <h4>No category available</h4>
                                                             <?php
                                                         }
                                                         ?>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">SubCategory Name</label>
                                                         <input type="text" name="SubCatName" value="<?= $crow['SubCatName']; ?>" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6">
                                                        </br>
                                                        <button type="submit" name="btnsubcatupdate" class="btn btn-primary"><i class="fas fa-save"></i> Add SubCategory</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }

                                            ?>
                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>