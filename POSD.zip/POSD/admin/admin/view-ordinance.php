<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Ordinance Details</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Ordinance Details</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-md-12">
                            <?php include('message.php'); ?>
                                <div class="card">
                                    <div class="card-header">
                                    <?php
                                            if(isset($_GET['id']))
                                            {
                                                
                                                $OrID = $_GET['id'];
                                                ?>
                                        <h4>Ordinance Details 
                                            <a href="list-ordinance.php"><i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                        <?php
                                                $CDetails = "SELECT * FROM ordinance WHERE OrID='$OrID' LIMIT 1";
                                                $CDetails_run = mysqli_query($con, $CDetails);
                                                if(mysqli_num_rows($CDetails_run) > 0)
                                                {    
                                                    $Detailsrow = mysqli_fetch_array($CDetails_run);
                                                    ?>
                                            <form action="function.php" method="POST" enctype="multipart/form-data">
                                                <div class="row">
                                                        <input type="hidden" name="OrID" value="<?= $Detailsrow['OrID']; ?>" class="form-control">
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Ordinance Number</label>
                                                         <input type="text" name="OrdinanceNo" value="<?= $Detailsrow['OrdinanceNo']; ?>" class="form-control" required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Ordinance Title</label>
                                                         <input type="text" name="Title" value="<?= $Detailsrow['Title']; ?>" class="form-control" required>
                                                     </div>
                                                     <div class="col-xl-6 col-md-12">
                                                    </div>
                                                     
                                                     <div class="col-xl-9 col-md-6">
                                                     </div>
                                                     <div class="col-xl-6 col-md-6">
                                                     <label for="">Description</label>
                                                         <textarea  name="Description" cols="30" rows="5" class="form-control" required><?= $Detailsrow['OrdinanceNo']; ?></textarea>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6">
                                                         <input type="text" name="OldFileName" value="<?= $Detailsrow['Image']; ?>">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                </br>
                                                     <img src="../../assets/ordinance/<?= $Detailsrow['Image'];?>" class="w-100" height="200px">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                     <label for="">If you need to change image</label>
                                                         <input type="file" name="Image" class="form-control">
                                                         <br>
                                                         <button type="submit" name="btnordiupdate" class="btn btn-primary mt-4 float-end" ><i class="fas fa-save"></i> Update Ordinance</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>