<?php
include('authentication.php');
include('midleware/sadminauth.php');
include('includes/header.php');
include('dbresbackup.php');
$connect = new PDO("mysql:host=localhost;dbname=posd", "root", "");
$get_all_table_query = "SHOW TABLES";
$statement = $connect->prepare($get_all_table_query);
$statement->execute();
$result = $statement->fetchAll();

if(isset($_POST['table']))
{
 $output = '';
 foreach($_POST["table"] as $table)
 {
  $show_table_query = "SHOW CREATE TABLE " . $table . "";
  $statement = $connect->prepare($show_table_query);
  $statement->execute();
  $show_table_result = $statement->fetchAll();

  foreach($show_table_result as $show_table_row)
  {
   $output .= "\n\n" . $show_table_row["Create Table"] . ";\n\n";
  }
  $select_query = "SELECT * FROM " . $table . "";
  $statement = $connect->prepare($select_query);
  $statement->execute();
  $total_row = $statement->rowCount();

  for($count=0; $count<$total_row; $count++)
  {
   $single_result = $statement->fetch(PDO::FETCH_ASSOC);
   $table_column_array = array_keys($single_result);
   $table_value_array = array_values($single_result);
   $output .= "\nINSERT INTO $table (";
   $output .= "" . implode(", ", $table_column_array) . ") VALUES (";
   $output .= "'" . implode("','", $table_value_array) . "');\n";
  }
 }
 $file_name = 'database_backup_on_' . date('y-m-d') . '.sql';
 $file_handle = fopen($file_name, 'w+');
 fwrite($file_handle, $output);
 fclose($file_handle);
 header('Content-Description: File Transfer');
 header('Content-Type: application/octet-stream');
 header('Content-Disposition: attachment; filename=' . basename($file_name));
 header('Content-Transfer-Encoding: binary');
 header('Expires: 0');
 header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file_name));
    ob_clean();
    flush();
    readfile($file_name);
    unlink($file_name);
}
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Backup & Restore</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Backup & Restore</li>
                        </ol>
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Backup & Restore
                                        <a href="index.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                       </div>
                                        <div class="card-body">
                                       <div class="embed-responsive embed-responsive-16by9">
                                        <iframe class="embed-responsive-item" src="fdbbackup.php" scrolling="no" style=" width: 300px; height: 270px;  overflow: hidden;" ></iframe>
                                        </div>
                                        <hr>
                                        <?php include('message.php'); ?>
                                        <div class="col-xl-3 col-md-6">
                                        <form method="post" enctype="multipart/form-data">
                                            <p><label>Select Sql Backup File</label>
                                            <input type="file" name="database" class="form-control"/></p>
                                            <input type="submit" name="import" class="btn btn-danger mt-1" value="Restore" onclick="return confirm('Are you sure you want to RESTORE this database?')"/>
                                            </br>
                                            <p><b>NOTE:</b> Use this function in time with no activity on the system and make sure that you have backup your database first. </p>
                                                         
                                        </div>
                                        </div>
                                </div>
                            </div>
                        </div>
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>