<?php
include('authentication.php');
include('midleware/sadminauth.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Complaint Details</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Complaint Details</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-md-12">
                            <?php include('message.php'); ?>
                                <div class="card">
                                    <div class="card-header">
                                    <?php
                                            if(isset($_GET['id']))
                                            {
                                                
                                                $CaseNo = $_GET['id'];
                                                ?>
                                        <h4>Complaint Details
                                            <a href="caddemail.php?id=<?php echo $CaseNo; ?>"> <i class="fa fa-envelope float-end"></i></a>
                                            <a href="csent-history.php?id=<?php echo $CaseNo; ?>"> <i class="fa fa-history float-end  me-3"></i></a>
                                            <a href="list-complaint.php?id=<?php echo $CaseNo; ?>"> <i class="fa fa-arrow-left float-end  me-3"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                           
                                                <?php
                                                $CDetails = "SELECT * FROM complain WHERE CaseNo='$CaseNo' ";
                                                $CDetails_run = mysqli_query($con, $CDetails);
                                                if(mysqli_num_rows($CDetails_run) > 0)
                                                {    
                                                    foreach($CDetails_run as $Details)
                                                    {
                                                    ?>
                                                    <?php
                                                        $timestamp = $Details['DateComplained'];
                                                        
                                                    ?>
                                            <form action="function.php" method="POST">
                                                <div class="row">
                                                <input type="hidden" name="" class="form-control">
                                                <div class="col-xl-3 col-md-6">
                                                         <label for="">Case No</label>
                                                         <input type="text" name="CaseNo" value="<?=$Details['CaseNo'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-6 col-md-12">
                                                     </div>

                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Date of Complaint</label>
                                                         <input type="text" name="DateComplained" value="<?php echo date('M d, Y', strtotime($timestamp)); ?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">First Name</label>
                                                         <input type="text" name="CFirstName" value="<?=$Details['CFirstName'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">LastName</label>
                                                         <input type="text" name="CLastName" value="<?=$Details['CLastName'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                     <label for="">Email</label>
                                                         <input type="text" name="CEmail" value="<?=$Details['CEmail'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Complainant Category</label>
                                                         <input type="text" name="CCategory" value="<?=$Details['CCategory'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-12 col-md-12">
                                                         <strong><p class="mt-4">Vehicle Details</p></strong>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Type of Vehicle</label>
                                                         <input type="text" name="VType" value="<?=$Details['VType'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Operator Name</label>
                                                         <input type="text" name="VOperatorName" value="<?=$Details['VOperatorName'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Plate No</label>
                                                         <input type="text" name="VPlateNo" value="<?=$Details['VPlateNo'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Code No</label>
                                                         <input type="text" name="VCode" value="<?=$Details['VCode'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Vechicle Organization</label>
                                                         <input type="text" name="VOrganization" value="<?=$Details['VOrganization'];?>" class="form-control">
                                                     </div>
                                                     <strong><hr class="mt-4 border bg-light"></strong>
                                                    
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Type of Complaint</label>
                                                         <?php
                                                         $GetCat = "SELECT * FROM category";
                                                         $GetCat_run = mysqli_query($con, $GetCat);
                                                         if(mysqli_num_rows($GetCat_run) > 0)
                                                         {
                                                             ?>
                                                         <select name="ComplaintType" class="form-control">
                                                         <option value="0">--Select Category Name--</option>
                                                         <?php
                                                         foreach($GetCat_run as $CatItem)
                                                         {
                                                             ?>
                                                             <option value="<?= $CatItem['CatName'];?>" <?= $CatItem['CatName'] == $Details['ComplaintType'] ? 'selected':'' ?>><?= $CatItem['CatName'];?></option>
                                                             <?php
                                                         }
                                                         ?>
                                                         </select>
                                                         <?php
                                                         }
                                                         else
                                                         {
                                                             ?>
                                                             <p>No Category list</p>
                                                             <?php
                                                         }
                                                         ?>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Sub Complaint</label>
                                                         <?php
                                                         $GetSCat = "SELECT * FROM subcategory";
                                                         $GetSCat_run = mysqli_query($con, $GetSCat);
                                                         if(mysqli_num_rows($GetSCat_run) > 0)
                                                         {
                                                             ?>
                                                         <select name="SubComplaint" class="form-control">
                                                         <option value="0">--Select SubCategory Name--</option>
                                                         <?php
                                                         foreach($GetSCat_run as $SCatItem)
                                                         {
                                                             ?>
                                                             <option value="<?= $SCatItem['SubCatName'];?>" <?= $SCatItem['SubCatName'] == $Details['SubComplaint'] ? 'selected':'' ?>><?= $SCatItem['SubCatName'];?></option>
                                                             <?php
                                                         }
                                                         ?>
                                                         </select>
                                                         <?php
                                                         }
                                                         else
                                                         {
                                                             ?>
                                                             <p>No Category list</p>
                                                             <?php
                                                         }
                                                         ?>
                                                     </div>
                                                     <div class="col-xl-6 col-md-6">
                                                        <label for="">Location of Incident</label>
                                                         <input type="text" name="LocIncident" value="<?=$Details['LocIncident'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">From:</label>
                                                         <input type="text" name="BFrom" value="<?=$Details['BFrom'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">To:</label>
                                                         <input type="text" name="BTo" value="<?=$Details['BTo'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Complaint Status</label>
                                                         <select name="Status" id=""class="form-control" required>
                                                            <option value="">--Select Status--</option>
                                                            <option value="1" <?= $Details['Status'] == '1' ? 'selected':'' ?>>Unidentified</option>
                                                            <option value="2" <?= $Details['Status'] == '2' ? 'selected':'' ?>>Open</option>
                                                            <option value="3" <?= $Details['Status'] == '3' ? 'selected':'' ?>>Closed</option>
                                                         </select>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Officer in Charge</label>
                                                         <input type="text" name="ROfficer" value="<?=$Details['ROfficer'];?>" class="form-control" required>
                                                     </div>
                                                     <div class="col-xl-6 col-md-6">
                                                        <label for="">Complaint Details</label>
                                                         <textarea name="CDetails" id="" cols="30" rows="5" class="form-control" readonly><?=$Details['CDetails'];?></textarea>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Proof of Evidence</label>
                                                        <a data-bs-toggle="modal" data-bs-target="#reg-modal">
                                                         <img src="../../assets/proof/<?=$Details['CProof'];?>" alt="" height="130px" class="form-control"></a>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                     <br><br><br><br>
                                                         <button type="submit" name="btncupdate" class="btn btn-primary mt-4 float-end" ><i class="fas fa-save"></i> Update</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>