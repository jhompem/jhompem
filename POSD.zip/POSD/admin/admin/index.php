<?php
include('authentication.php');
include('midleware/sadminauth.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">POSD Cauayan Admin Panel</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                        <div class="row">
                            
                         <?php include('message.php'); ?>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">Total Complainant
                                        <?php
                                            $dash_complainant = "SELECT * FROM complain";
                                            $dash_complainant_run = mysqli_query($con, $dash_complainant);
                                            $complaint = mysqli_num_rows($dash_complainant_run);
                                            if($comptotal = mysqli_num_rows($dash_complainant_run))
                                            {
                                                echo ' <h2 class="mb-0">'.$comptotal.'</h2>';
                                            }
                                            else
                                            {
                                                echo ' <h2 class="mb-0">0</h2>';
                                            }
                                        ?>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#"></a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body">Total Closed Complaint
                                        <?php
                                            $dash_close = "SELECT * FROM complain WHERE status='3'";
                                            $dash_close_run = mysqli_query($con, $dash_close);
                                            $closed = mysqli_num_rows($dash_close_run);

                                            if($tclose = mysqli_num_rows($dash_close_run))
                                            {
                                                echo ' <h2 class="mb-0">'.$tclose.'</h2>';
                                            }
                                            else
                                            {
                                                echo ' <h2 class="mb-0">0</h2>';
                                            }
                                        ?>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#"></a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body">Total Undefine
                                        <?php
                                            $dash_undi = "SELECT * FROM complain WHERE status='1'";
                                            $dash_undi_run = mysqli_query($con, $dash_undi);
                                            $undefined = mysqli_num_rows($dash_undi_run);

                                            if($tundi = mysqli_num_rows($dash_undi_run))
                                            {
                                                echo ' <h2 class="mb-0">'.$tundi.'</h2>';
                                            }
                                            else
                                            {
                                                echo ' <h2 class="mb-0">0</h2>';
                                            }
                                        ?>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#"></a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
                                    <div class="card-body">Total Open Complaint
                                        <?php
                                            $dash_opem = "SELECT * FROM complain WHERE status='2'";
                                            $dash_open_run = mysqli_query($con, $dash_opem);
                                            $open = mysqli_num_rows($dash_open_run);

                                            if($topen = mysqli_num_rows($dash_open_run))
                                            {
                                                echo ' <h2 class="mb-0">'.$topen.'</h2>';
                                            }
                                            else
                                            {
                                                echo ' <h2 class="mb-0">0</h2>';
                                            }
                                        ?>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href=""></a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>

 <div class="col-xl-12 col-md-6">
<script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
         ['',''],
         <?php
         $text = ['Complaint','Closed','Undefined','Open'];
         $value = [$complaint,$closed,$undefined,$open];
         for($i=0;$i<4;$i++){
             echo "['".$text[$i]."', '".$value[$i]."'],";
         }

         ?>
         
          /*['Year', 'Sales'],
          ['2014', 1000],
          ['2015', 1170],
          ['2016', 660],
          ['2017', 1030]*/
        ]);

        var options = {
          chart: {
            title: '',
            subtitle: '',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
      google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawChart);
    </script>
    <div class="row" id="columnchart_material" style="max-width:100%; height: 250px;"></div>
</div>

 </div>



</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>