<?php
include('authentication.php');


if(isset($_POST['btnordiupdate']))
{
    $OrID = $_POST['OrID'];
    $OrdinanceNo = $_POST['OrdinanceNo'];
    $Title = $_POST['Title'];
    $Description = $_POST['Description'];
    $OldFileName =$_POST['OldFileName'];  
    $Image = $_FILES['Image']['name'];
    $UpdateFileName = "";
    $path = "../../assets/ordinance/";
    if($Image != NULL)
    {
    $image_extension = pathinfo($Image, PATHINFO_EXTENSION);
    $FileName = time().'.'.$image_extension;
    $UpdateFileName = $FileName;
    }
    else
    {
    $UpdateFileName = $OldFileName;
    }

    $query = "UPDATE ordinance SET OrdinanceNo='$OrdinanceNo', Title='$Title', Description='$Description', Image='$UpdateFileName' WHERE OrID='$OrID'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        if($Image != NULL)
        {
            if(file_exists($path."/".$OldFileName)){
                unlink($path."/".$OldFileName);
            }
        move_uploaded_file($_FILES['Image']['tmp_name'], $path."/".$UpdateFileName);
        }


        $_SESSION['message'] = "Updated successfully";
        header('Location: view-ordinance.php?id='.$OrID);
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Something went wrong!";
        header('Location: view-ordinance.php?id='.$OrID);
        exit(0);
    }
}


if(isset($_POST['btnordiadd']))
{
	$OrdinanceNo = $_POST['OrdinanceNo'];
	$Title = $_POST['Title'];
	$Description = $_POST['Description'];
    $image = $_FILES['Image']['name'];
    $path = "../../assets/ordinance/"; 
    $image_extension = pathinfo($image, PATHINFO_EXTENSION);
    $filename = time().'.'.$image_extension; 
    
    $query = "INSERT INTO ordinance (OrdinanceNo,Title,Description,Image) VALUES ('$OrdinanceNo','$Title','$Description','$filename')";
    $query_run = mysqli_query($con, $query);


        if($query_run)
        {
            move_uploaded_file($_FILES['Image']['tmp_name'], $path."/".$filename);

            $_SESSION['message'] = "Post added successfully";
            header('Location: addordinance.php');
            exit(0);
        
        }
        else
        {
            $_SESSION['message'] = "Somethine went wrong!";
            header('Location: addordinance.php');
            exit(0);
        }

}



if(isset($_POST['btnnewsdelete']))
{
    $path = "../../assets/news/";
    $NewsID = $_POST['btnnewsdelete'];
    
    $check_img = "SELECT * FROM news WHERE NewsID='$NewsID' LIMIT 1";
    $check_res = mysqli_query($con, $check_img);
    $res_data = mysqli_fetch_array($check_res);

    $image = $res_data['Image'];
    $query = "DELETE FROM news WHERE NewsID='$NewsID' LIMIT 1";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        if(file_exists('../../assets/news/'.$image)){
            unlink("../../assets/news/".$image);
        }
        $_SESSION['message'] = "Post Deleted successfully";
        header("Location: list-news.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: list-news.php");
        exit(0);
    }
}


if(isset($_POST['btnnewsadd']))
{
	$Title = $_POST['Title'];
    $image = $_FILES['Image']['name'];
	$status = $_POST['status'];
    $path = "../../assets/news/";
    $image_extension = pathinfo($image, PATHINFO_EXTENSION);
    $filename = time().'.'.$image_extension; 
    
    $query = "INSERT INTO news (Title,Image,status) VALUES ('$Title','$filename','$status')";
    $query_run = mysqli_query($con, $query);

        if($query_run)
        {
            move_uploaded_file($_FILES['Image']['tmp_name'], $path."/".$filename);

            $_SESSION['message'] = "Post added successfully";
            header('Location: addnews.php');
            exit(0);
        
        }
        else
        {
            $_SESSION['message'] = "Somethine went wrong!";
            header('Location: addnews.php');
            exit(0);
        }

}

if(isset($_POST['btnfaqsdelete']))
{
    $fid = $_POST['btnfaqsdelete'];
    $query = "DELETE FROM faqs WHERE ID='$fid'";
    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "FAQ's Deleted successfully";
        header("Location: list-faqs.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: list-faqs.php");
        exit(0);
    }
}


if(isset($_POST['btnordelete']))
{
    $path = "../../assets/ordinance/";
    $OrID = $_POST['btnordelete'];
    
    $check_img = "SELECT * FROM ordinance WHERE OrID='$OrID' LIMIT 1";
    $check_res = mysqli_query($con, $check_img);
    $res_data = mysqli_fetch_array($check_res);

    $image = $res_data['Image'];
    $query = "DELETE FROM ordinance WHERE OrID='$OrID' LIMIT 1";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        if(file_exists('../../assets/ordinance/'.$image)){
            unlink("../../assets/ordinance/".$image);
        }
        $_SESSION['message'] = "Ordinance Deleted successfully";
        header("Location: list-ordinance.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: list-ordinance.php");
        exit(0);
    }

}


if(isset($_POST['btnfaqs']))
{
    $Question = $_POST['Question'];
    $Answer = $_POST['Answer'];

    $query ="INSERT INTO faqs (Question,Answer) VALUES ('$Question','$Answer')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "FAQ's Added successfully";
        header("Location: list-faqs.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: view-register.php");
        exit(0);
    }
}

if(isset($_POST['btnsendmail']))
{
    $CaseNo = $_POST['CaseNo'];
    $SenderID = $_POST['SenderID'];
    $Sender = $_POST['Sender'];
    $Mto = $_POST['Mto'];
    $MSubject = $_POST['MSubject'];
    $MBody = $_POST['MBody'];
    $Purpose = $_POST['Purpose'];
    $CaseStatus = $_POST['Status'];

    $query ="INSERT INTO message (CaseNo, SenderID, Sender, Mto, MSubject, MBody, Purpose, CaseStatus) VALUES ('$CaseNo','$SenderID','$Sender','$Mto','$MSubject','$MBody','$Purpose','$CaseStatus')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {

            $to = $Mto;
			$Subject = $MSubject;
			$Message=" Good day!<br>
            <p>$MBody<br><br><br>
            
            Thank you!<br><br>
            POSD Cauayan
            <p><i><b>Note:</b>
            This process is designed to reduce fake complaints and users trying out our innovative technology. so please follow the process correctly for the benefit of our new system and that we can respond quickly to your complaint</i></p><br>
            <p><i>This email message (including attachments, if any) is intended for the use of the individual or the entity to whom it is addressed and may contain information that is privileged, proprietary, confidential and exempt from disclosure. If you are not an intended recipient of this e-mail, you are not authorized to duplicate, copy, retransmit, or redistribute it by any means. Please delete it and any attachments immediately and notify the sender that you have received it in error.</i></p>";
			$headers ="From: cauayanposd@gmail.com \r\n";
			$headers .="MTME-Version: 1.0" ."\r\n";
			$headers .="Content-type:text/html;charset-UTF-8" . "\r\n";
			mail($to,$Subject,$Message,$headers);

        $_SESSION['message'] = "Message sent successfully";
        header("Location: view-sent.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: view-sent.php");
        exit(0);
    }
}



if(isset($_POST['btndelete']))
{
    $user_id = $_POST['btndelete'];
    $query = "DELETE FROM accounts WHERE UserID='$user_id'";
    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Deleted successfully";
        header("Location: view-register.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: view-register.php");
        exit(0);
    }
}

if(isset($_POST['btncatdelete']))
{
    $Catid = $_POST['btncatdelete'];
    $query = "DELETE FROM category WHERE CatID='$Catid'";
    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Category Deleted successfully";
        header("Location: category.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: category.php");
        exit(0);
    }
}

if(isset($_POST['btnsubcatdelete']))
{
    $Subcatid = $_POST['btnsubcatdelete'];
    $query = "DELETE FROM subcategory WHERE SubID='$Subcatid'";
    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Category Deleted successfully";
        header("Location: category.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: category.php");
        exit(0);
    }
}


if(isset($_POST['btnadd']))
{
    $UserID = $_POST['UserID'];
    $FirstName = $_POST['FirstName'];
    $LastName = $_POST['LastName'];
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];
    $Address = $_POST['Address'];
    $Mobile = $_POST['Mobile'];
    $UserLevel = $_POST['UserLevel'];

    $query ="INSERT INTO accounts (UserID,FirstName,LastName,Email,Password,Address,Mobile,UserLevel) VALUES ('$UserID','$FirstName','$LastName','$Email','$Password','$Address','$Mobile','$UserLevel')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated successfully";
        header("Location: view-register.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: view-register.php");
        exit(0);
    }
}

if(isset($_POST['btncatadd']))
{
    $CatName = $_POST['CatName'];
   
    $query ="INSERT INTO category (CatName) VALUES ('$CatName')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Category added successfully";
        header("Location: addcategory.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: view-register.php");
        exit(0);
    }
}

if(isset($_POST['btnsubcatadd']))
{
    $CatID = $_POST['CatID'];
    $SubCatName = $_POST['SubCatName'];
   
    $query ="INSERT INTO subcategory (CatID,SubCatName) VALUES ('$CatID','$SubCatName')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "SubCategory added successfully";
        header("Location: addcategory.php");
        exit(0);
    
    }
    else
    {
        $_SESSION['message'] = "Somethine went wrong!";
        header("Location: view-register.php");
        exit(0);
    }
}


if(isset($_POST['btnupdate']))
{
    $UserID = $_POST['UserID'];
    $FirstName = $_POST['FirstName'];
    $LastName = $_POST['LastName'];
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];
    $Address = $_POST['Address'];
    $Mobile = $_POST['Mobile'];
    $UserLevel = $_POST['UserLevel'];

    $query = "UPDATE accounts SET FirstName='$FirstName', LastName='$LastName', Email='$Email', Password='$Password', Address='$Address', Mobile='$Mobile', UserLevel='$UserLevel' WHERE UserID='$UserID' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated successfully";
        header("Location: view-register.php");
        exit(0);
    }
}

if(isset($_POST['btncatupdate']))
{
    $CatID = $_POST['CatID'];
    $CatName = $_POST['CatName'];
    $query = "UPDATE category SET CatName='$CatName' WHERE CatID='$CatID' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated successfully";
        header("Location: category.php");
        exit(0);
    }
}

if(isset($_POST['btnsubcatupdate']))
{
    $SubID = $_POST['SubID'];
    $CatID = $_POST['CCatID'];
    $SubCatName = $_POST['SubCatName'];
    $query = "UPDATE subcategory SET  CatID='$CatID', SubCatName='$SubCatName' WHERE SubID='$SubID' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated successfully";
        header("Location: category.php");
        exit(0);
    }
}

if(isset($_POST['btncupdate']))
{
    $CaseNo = $_POST['CaseNo'];
    $VOperatorName = $_POST['VOperatorName'];
    $ComplaintType = $_POST['ComplaintType'];
    $SubComplaint = $_POST['SubComplaint'];
    $VOrganization = $_POST['VOrganization'];
    $Status = $_POST['Status'];
    $ROfficer = $_POST['ROfficer'];
    $DateRespond = date("Y/m/d");
    $query = "UPDATE complain SET  VOperatorName='$VOperatorName', ComplaintType='$ComplaintType',SubComplaint='$SubComplaint', VOrganization='$VOrganization', Status='$Status', ROfficer='$ROfficer', DateRespond='$DateRespond' WHERE CaseNo='$CaseNo' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated successfully! Please send email to complainant for update and to provide history into the case.";
        header('Location: caddemail.php?id='.$CaseNo);
        exit(0);
    }
}

if(isset($_POST['btnucupdate']))
{
    $year = date("Y");
    $Code = rand(1,99999);
    $CaseNo = $year."-". $Code;
    $CaseID = $_POST['CaseID'];
    $VOperatorName = $_POST['VOperatorName'];
    $ComplaintType = $_POST['ComplaintType'];
    $SubComplaint = $_POST['SubComplaint'];
    $VOrganization = $_POST['VOrganization'];
    $Status = $_POST['Status'];
    $ROfficer = $_POST['ROfficer'];
    $DateRespond = date("Y/m/d");
    $query = "UPDATE complain SET  CaseNo='$CaseNo', VOperatorName='$VOperatorName', ComplaintType='$ComplaintType',SubComplaint='$SubComplaint', VOrganization='$VOrganization', Status='$Status', ROfficer='$ROfficer', DateRespond='$DateRespond' WHERE CaseID='$CaseID' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated successfully! Please send email to complainant for update and to provide history into the case.";
        header('Location: caddemail.php?id='.$CaseNo);
        exit(0);
    }
}



if(isset($_POST['btnfupdate']))
{ 
   $fid = $_POST['Fid'];
   $Q = $_POST['Question'];
   $A = $_POST['Answer'];

   $query = "UPDATE faqs SET Question='$Q', Answer='$A' WHERE ID='$fid' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "FAQ's Updated successfully";
        header("Location: list-faqs.php");
        exit(0);
    }
}
else
{
    echo 'tatay mo';
}



?>