<?php
include('authentication.php');
include('midleware/sadminauth.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Registered User</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Registered User</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-xl-12">
                                <?php include('message.php'); ?>
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Registered User
                                        <a href="adduser.php"> <i class="fa fa-plus float-end"></i></a>
                                        </h4>
                                       </div>
                                        <div class="card-body">
                                        <div class="table-responsive">
                                         <table id="tblusers" class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>User ID</th>
                                                        <th>First Name</th>
                                                        <th>Last Name</th>
                                                        <th>Address</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>User Level</th>
                                                        <th>Edit</th>
                                                        <?php if($_SESSION['auth_role'] == '2') : ?>
                                                        <th>Delete</th>
                                                        <?php endif; ?>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $query = "SELECT * FROM accounts WHERE UserLevel !='1'";
                                                    $query_run = mysqli_query($con, $query);

                                                    if(mysqli_num_rows($query_run) > 0)
                                                    {

                                                        foreach($query_run as $row)
                                                        {
                                                            ?>

                                                    <tr>
                                                        <td><?= $row['UserID']; ?></td>
                                                        <td><?= $row['FirstName']; ?></td>
                                                        <td><?= $row['LastName']; ?></td>
                                                        <td><?= $row['Address']; ?></td>
                                                        <td><?= $row['Email']; ?></td>
                                                        <td><?= $row['Mobile']; ?></td>
                                                        <td>
                                                            <?php
                                                            if($row['UserLevel'] == '0')
                                                            {
                                                                echo 'Admin';
                                                            }
                                                            elseif ($row['UserLevel'] == '1')
                                                            {
                                                                echo 'User';
                                                            }
                                                            elseif ($row['UserLevel'] == '2')
                                                            {
                                                                echo 'Super Admin';
                                                            }
                                                            else
                                                            {
                                                                echo 'No user level';
                                                            }
                                                            ?>
                                                            
                                                        </td>
                                                        <td><a href="register-edit.php?id=<?=$row['UserID'];?>" class="btn btn-success"><i class="fas fa-edit"></i></a></td>
                                                        <?php if($_SESSION['auth_role'] == '2') : ?>
                                                        <td>
                                                            <form action="function.php" method = "POST">
                                                                <button type="submit" name="btndelete" value="<?= $row['UserID']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to DELETE this?')"><i class="fas fa-trash-alt"></i></button>
                                                            </form>
                                                            </td>
                                                            <?php endif; ?>
                                                    </tr>

                                                            <?php
                                                        }

                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        <td colspan="8">No Record Found</td>
                                                        <?php
                                                    }

                                                    ?>
                                                    
                                                </tbody>
                                            </table>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>