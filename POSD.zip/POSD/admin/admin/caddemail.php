<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Send Email</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Send Email</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-md-12">
                                
                            <?php include('message.php'); ?>
                                <div class="card">
                                    <div class="card-header">
                                    <?php
                                            if(isset($_GET['id']))
                                            {
                                                
                                                $CaseNo = $_GET['id'];
                                                ?>
                                        <h4>Send Email<a href="view-complaint.php?id=<?php echo $CaseNo; ?>"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                        <?php
                                                $CDetails = "SELECT * FROM complain WHERE CaseNo='$CaseNo' ";
                                                $CDetails_run = mysqli_query($con, $CDetails);
                                                if(mysqli_num_rows($CDetails_run) > 0)
                                                {    
                                                    foreach($CDetails_run as $Details)
                                                    {
                                                    ?>
                                                    <?php
                                                        $timestamp = $Details['DateComplained'];
                                                        
                                                    ?>
                                                <form action="function.php" method="POST">
                                                <div class="row">
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Case No</label>
                                                         <input type="text" name="CaseNo" value="<?=$Details['CaseNo'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <input type="hidden" name="Status" value="<?=$Details['Status'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Purpose of Email</label>
                                                         <input type="text" name="Purpose" class="form-control"minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">From</label>
                                                         <input type="text" name="MFrom" class="form-control" value="cauayanposd@gmail.com" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">To</label>
                                                         <input type="email" name="Mto" class="form-control" minlength="2" pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$" title = "Please input a valid email format eg. cauayan@isabela.com" required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Subject</label>
                                                         <input type="text" name="MSubject" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">User Sender</label>
                                                         <input type="text" name="Sender" class="form-control" value="<?= $_SESSION['auth_user']['UFullName']; ?>" readonly>
                                                         <label name="SenderID"for=""hidden><?= $_SESSION['auth_user']['UserID']; ?></label>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6 mt-3">
                                                         <hr>
                                                     </div>
                                                     
                                                     <div class="col-xl-12 col-md-6">
                                                         <label for="">Email Body</label>
                                                        <textarea name="MBody" id="" cols="30" rows="5" class="form-control" required></textarea>
                                                     </div>
                                                     <div class="col-md-12 ">
                                                        </br>
                                                         <button type="submit" name="btnsendmail" class="btn btn-primary float-end"><i class="fas fa-paper-plane"></i> Send Email</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>