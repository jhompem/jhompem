<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">FAQ's Details</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">FAQ's Details</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>FAQ's Details<a href="list-faqs.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                            <?php
                                            if(isset($_GET['id']))
                                            {
                                                $faqs_id = $_GET['id'];
                                                $faqs = "SELECT * FROM faqs WHERE ID='$faqs_id' ";
                                                $faqs_run = mysqli_query($con, $faqs);
                                                if(mysqli_num_rows($faqs_run) > 0)
                                                {
                                                    foreach($faqs_run as $Details)
                                                    {
                                                    ?>
                                            <form action="function.php" method="POST">
                                                <div class="row">
                                                <input type="hidden" name="Fid" value="<?=$Details['ID'];?>" class="form-control">
                                                    <div class="col-xl-6 col-md-6">
                                                         <label for="">Question</label>
                                                         <input type="text" name="Question" value="<?=$Details['Question'];?>" class="form-control" required>
                                                     </div>
                                                     <div class="col-xl-9 col-md-6">
                                                         <label for="">Answer</label>
                                                         <textarea name="Answer" cols="30" rows="10" class="form-control" required><?=$Details['Answer'];?></textarea>
                                                     </div>
                                                     <div class="col-md-12 ">
                                                        </br>
                                                         <button type="submit" name="btnfupdate" class="btn btn-primary"><i class="fa fa-save"></i> Update FAQ's</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>