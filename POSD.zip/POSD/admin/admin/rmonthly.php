<?php
include('authentication.php');
include('midleware/sadminauth.php');
include('includes/header.php');
?>
                    <div class="container-fluid px-4">
                        <h4 class="mt-4">Monthly Reports</h4>
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Daily Data Table
                            </div>
                            <div class="table-responsive">
                                         <table id="tblcomp" class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Case No</th>
                                                        <th>First Name</th>
                                                        <th>Last Name</th>
                                                        <th>Date of Complaint</th>
                                                        <th>Officer In Charge</th>
                                                        <th>Date Respond</th>
                                                        <th>Status</th>
                                                        <?php if($_SESSION['auth_role'] == '2') : ?>
                                                        <th>View</th>
                                                        <?php endif; ?>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $query = "SELECT * FROM complain WHERE YEAR(DateComplained) = YEAR(NOW()) AND MONTH(DateComplained)=MONTH(NOW())";
                                                    $query_run = mysqli_query($con, $query);

                                                    if(mysqli_num_rows($query_run) > 0)
                                                    {

                                                        foreach($query_run as $row)
                                                        {
                                                            $timestamp = $row['DateComplained'];
                                                            $timestamp1 = $row['DateRespond'];
                                                            ?>

                                                    <tr>
                                                        <td><?= $row['CaseNo']; ?></td>
                                                        <td><?= $row['CFirstName']; ?></td>
                                                        <td><?= $row['CLastName']; ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($timestamp)); ?></td>
                                                        <td><?= $row['ROfficer']; ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($timestamp1)); ?></td>
                                                        <td>
                                                            <?php
                                                            if($row['Status'] == '2')
                                                            {
                                                                echo 'Open';
                                                            }
                                                            elseif ($row['Status'] == '3')
                                                            {
                                                                echo 'Closed';
                                                            }
                                                            else
                                                            {
                                                                echo 'Undifined';
                                                            }
                                                            ?>
                                                            
                                                        </td>
                                                        <?php if($_SESSION['auth_role'] == '2') : ?>
                                                        <td>
                                                            <a href="view-complaint.php?id=<?=$row['CaseNo'];?>" class="btn btn-success"><i class="fas fa-eye"></i></a>
                                                        </td>
                                                        <?php endif; ?>
                                                    </tr>

                                                            <?php
                                                        }

                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        <td colspan="8">No Record Found</td>
                                                        <?php
                                                    }

                                                    ?>
                                                    
                                                </tbody>
                                            </table>
                                                </div>
                           <div class="card-footer small text-muted">Updated</div>
                        </div>

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-bar me-1"></i>
                                        Complaint Category
                                    </div>
                                    <?php
                                    try {
                                        $con = new PDO ("mysql:host=localhost;dbname=posd","root","");

                                    } catch(PDOExection $e) {
                                        echo $e->getMessage();
                                    }

                                        $sql="SELECT Count(ComplaintType) as ccount, ComplaintType from complain WHERE YEAR(DateComplained) = YEAR(NOW()) AND MONTH(DateComplained)=MONTH(NOW()) AND ComplaintType !='' group by ComplaintType";
                                        $stmt=$con->prepare($sql);
                                        $stmt->execute();
                                        $arr=$stmt->fetchAll(PDO::FETCH_ASSOC);

                                    ?>
                                    <script type="text/javascript">
                                        google.charts.load('current', {'packages':['bar']});
                                        google.charts.setOnLoadCallback(drawChart);

                                        function drawChart() {
                                            var data = google.visualization.arrayToDataTable([
                                            
                                                ['',''],

                                                <?php foreach ($arr as $key=>$val) {?>
                                                ['<?php echo $val['ComplaintType'] ?>',<?php echo $val['ccount']?>],
                                                <?php } ?>

                                            ]);

                                            var options = {
                                            chart: {
                                                title:      '',
                                                subtitle: '',
                                            }
                                            };

                                            var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

                                            chart.draw(data, google.charts.Bar.convertOptions(options));
                                        }
                                        google.load("visualization", "1", {packages:["corechart"]});
                                        google.setOnLoadCallback(drawChart);
                                        </script>
                                        <div class="row" id="columnchart_material" style="max-width:100%; height: 250px;"></div>
                                    <div class="card-footer small text-muted">Updated</div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-bar me-1"></i>
                                        Complaint Status
                                    </div>
                                    <?php
                                    try {
                                        $con = new PDO ("mysql:host=localhost;dbname=posd","root","");

                                    } catch(PDOExection $e) {
                                        echo $e->getMessage();
                                    }

                                        $sql=" SELECT count(Status) as scount, CASE WHEN Status = 1 THEN 'Undefined' WHEN Status = 2 THEN 'Open' WHEN Status = 3 THEN 'Closed'
                                            ELSE 'No status' END as cstatus FROM complain where YEAR(DateComplained) = YEAR(NOW()) AND MONTH(DateComplained)=MONTH(NOW()) group by Status";
                                        $stmt=$con->prepare($sql);
                                        $stmt->execute();
                                        $arr=$stmt->fetchAll(PDO::FETCH_ASSOC);

                                    ?>
                                    <script type="text/javascript">
                                        google.charts.load('current', {'packages':['bar']});
                                        google.charts.setOnLoadCallback(drawChart);

                                        function drawChart() {
                                            var data = google.visualization.arrayToDataTable([
                                            
                                                ['',''],

                                                <?php foreach ($arr as $key=>$val) {?>
                                                ['<?php echo $val['cstatus'] ?>',<?php echo $val['scount']?>],
                                                <?php } ?>

                                            ]);

                                            var options = {
                                            chart: {
                                                title:      '',
                                                subtitle: '',
                                            }
                                            };

                                            var chart = new google.charts.Bar(document.getElementById('columnchart_material1'));

                                            chart.draw(data, google.charts.Bar.convertOptions(options));
                                        }
                                        google.load("visualization", "1", {packages:["corechart"]});
                                        google.setOnLoadCallback(drawChart);
                                        </script>
                                        <div class="row" id="columnchart_material1" style="max-width:100%; height: 250px;"></div>
                                    <div class="card-footer small text-muted">Updated</div>
                                </div>
                            </div>
                        </div>
                    </div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>