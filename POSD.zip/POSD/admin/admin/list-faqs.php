<?php
include('authentication.php');
include('midleware/sadminauth.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">FAQ's List</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">FAQ's List</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-xl-12">
                                <?php include('message.php'); ?>
                                <div class="card">
                                    <div class="card-header">
                                        <h4>FAQ's List
                                            <a href="addfaqs.php"> <i class="fa fa-plus float-end"></i></a>
                                            <a href="index.php"> <i class="fa fa-arrow-left float-end  me-3"></i></a>
                                        </h4>
                                       </div>
                                        <div class="card-body">
                                        <div class="table-responsive">
                                         <table id="tblfaqs" class="table table-striped table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Question</th>
                                                        <th>Answere</th>
                                                        <th>Edit</th>
                                                        <th>Delete</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $query = "SELECT * FROM faqs";
                                                    $query_run = mysqli_query($con, $query);

                                                    if(mysqli_num_rows($query_run) > 0)
                                                    {

                                                        foreach($query_run as $row)
                                                        {
                                                            ?>
                                                            
                                                    <tr>
                                                        <td><?= $row['Question']; ?></td>
                                                        <td><?= $row['Answer']; ?></td>
                                                        <td>
                                                            <a href="view-faqs.php?id=<?=$row['ID'];?>" class="btn btn-success"><i class="fas fa-edit"></i></a>
                                                        </td>
                                                        <td>
                                                            <form action="function.php" method = "POST">
                                                                <button type="submit" name="btnfaqsdelete" value="<?= $row['ID']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to DELETE this?')"><i class="fas fa-trash-alt"></i></button>
                                                            </form>
                                                        </td>
                                                    </tr>

                                                            <?php
                                                        }

                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        <td colspan="4">No Record Found</td>
                                                        <?php
                                                    }

                                                    ?>
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>