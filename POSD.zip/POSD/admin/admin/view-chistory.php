<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">View Message</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">View Message</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                    <?php
                                            if(isset($_GET['id']))
                                            {
                                                
                                                $MID = $_GET['id'];
                                                $CDetails = "SELECT * FROM message WHERE MessageID='$MID' ";
                                                $CDetails_run = mysqli_query($con, $CDetails);
                                                if(mysqli_num_rows($CDetails_run) > 0)
                                                {
                                                    foreach($CDetails_run as $Details)
                                                      $msgid = $Details['CaseNo'];
                                                    {
                                                ?>
                                        <h4>View Message<a href="view-sent.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                                <form action="function.php" method="POST">
                                                <div class="row">
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Case No</label>
                                                         <input type="text" name="CaseNo" value="<?=$Details['CaseNo'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <input type="hidden" name="Status" value="<?=$Details['Status'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Purpose of Email</label>
                                                         <input type="text" name="Purpose" value="<?=$Details['Purpose'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">From</label>
                                                         <input type="text" name="MFrom" class="form-control" value="cauayanposd@gmail.com" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">To</label>
                                                         <input type="text" name="Mto" value="<?=$Details['Mto'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Subject</label>
                                                         <input type="text" name="MSubject" value="<?=$Details['MSubject'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">User Sender</label>
                                                         <input type="text" name="Sender" class="form-control" value="<?= $_SESSION['auth_user']['UFullName']; ?>" readonly>
                                                         <label name="SenderID"for=""hidden><?= $_SESSION['auth_user']['UserID']; ?></label>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6 mt-3">
                                                         <hr>
                                                     </div>
                                                     
                                                     <div class="col-xl-12 col-md-6">
                                                         <label for="">Email Body</label>
                                                        <textarea name="" id="" cols="30" rows="5" class="form-control" readonly><?=$Details['MBody'];?></textarea>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>