<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
                        <h4 class="mt-4">Edit Users</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item">Edit User</li>
                        </ol>
                        <div class="row">
                            
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Edit User<a href="view-register.php"> <i class="fa fa-arrow-left float-end"></i></a>
                                        </h4>
                                    </div>
                                        <div class="card-body">
                                            <?php
                                            if(isset($_GET['id']))
                                            {
                                                $user_id = $_GET['id'];
                                                $users = "SELECT * FROM accounts WHERE UserID='$user_id' ";
                                                $users_run = mysqli_query($con, $users);
                                                if(mysqli_num_rows($users_run) > 0)
                                                {
                                                    foreach($users_run as $user)
                                                    {
                                                    ?>
                                            <form action="function.php" method="POST">
                                                <div class="row">
                                                <input type="hidden" name="UserID" value="<?=$user['UserID'];?>" class="form-control">
                                                    <div class="col-xl-3 col-md-6">
                                                         <label for="">First Name</label>
                                                         <input type="text" name="FirstName" value="<?=$user['FirstName'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Last Name</label>
                                                         <input type="text" name="LastName" value="<?=$user['LastName'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Address</label>
                                                         <input type="text" name="Address" value="<?=$user['Address'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Email</label>
                                                         <input type="text" name="Email" value="<?=$user['Email'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Phone Number</label>
                                                         <input type="text" name="Mobile" value="<?=$user['Mobile'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Password</label>
                                                         <input type="password" name="Password" value="<?=$user['Password'];?>" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">User Level</label>
                                                         <select name="UserLevel" id=""class="form-control">
                                                            <option value="">--Select Role--</option>
                                                            <option value="0" <?= $user['UserLevel'] == '0' ? 'selected':'' ?>>Admin</option>
                                                            <option value="1" <?= $user['UserLevel'] == '1' ? 'selected':'' ?>>User</option>
                                                         </select>
                                                     </div>
                                                     <div class="col-md-12 ">
                                                        </br>
                                                         <button type="submit" name="btnupdate" class="btn btn-primary" ><i class="fas fa-user-edit"></i> Update User</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                </div>
                            </div>
                        </div>
                        
                        
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');

?>