<?php
session_start();
include('admin/config/dbcon.php');
include('includes/header.php');
include('includes/navbar.php');
?>

<div class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
            
            <?php include('message.php'); ?>

                <div class="card">
                    <card class="body">
                        <h4 class="text-center">Create Password</h4>
                    </card>
                    <div class="card-body">
                        <?php

                    if(isset($_GET['vkey']))
                                            {
                                                
                                                $Vkey = $_GET['vkey'];
                                                ?>
                
                        <form action="allcode.php" method="POST">
                        <?php
                                                $CDetails = "SELECT * FROM accounts WHERE Vkey='$Vkey' ";
                                                $CDetails_run = mysqli_query($con, $CDetails);
                                                if(mysqli_num_rows($CDetails_run) > 0)
                                                {    
                                                    foreach($CDetails_run as $Details)
                                                    {
                                                    ?>
                    <div class="form-group mb-3">
                            <label>Email</label>
                            <input type="email" value="<?= $Details['Email']; ?>" name="Email" placeholder="Enter Email" class="form-control" readonly>
                            <input type="hidden" value="<?= $Details['Vkey']; ?>" name="Vkey" placeholder="Enter Email" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label>Current Address</label>
                            <input required type="text" name="Address" placeholder="Enter Complete Address (purok barangay municipality)" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label>Password</label>
                            <input required type="password" name="Password" placeholder="Enter Password" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label>Confirm Password</label>
                            <input required type="password" name="CPassword" placeholder="Enter Confirm Password" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" name="btncreatepass" class="btn btn-primary w-100">Create Password</button>
                        </div>
                        </form>
                        <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<br>
<br>
<br>
<br>
<?php
include('includes/footer.php');
?>