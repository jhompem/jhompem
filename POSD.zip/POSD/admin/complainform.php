<?php
session_start();
include('../admin/admin/config/dbcon.php');
include('includes/header.php');
include('includes/navbar.php');
?>


<div class="container-fluid px-4">
                      
                        <div class="row">
                            
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                    <?php
                                            if(isset($_GET['vkey']))
                                            {
                                                
                                                $Vkey = $_GET['vkey'];
                                                
                                                ?>
                                        <h4>Complaint Form</h4>
                                        <p>
                                            <i>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Note:</b>
                                                This process is designed to reduce fake complaints and users trying out our innovative technology. So please follow the process correctly for the benefit of our new system and that we can respond quickly to your complaint
                                            </i>
                                        </p>
            
                                    </div>
                                        <div class="card-body">
                                        <?php
                                                $CDetails = "SELECT * FROM complain WHERE Vkey='$Vkey' ";
                                                $CDetails_run = mysqli_query($con, $CDetails);
                                                if(mysqli_num_rows($CDetails_run) > 0)
                                                {    
                                                    foreach($CDetails_run as $Details)
                                                    {
                                                    ?>
                                                    <?php
                                                        $timestamp = $Details['DateComplained'];
                                                        
                                                    ?>
                                                
                                            <form action="allcode.php" method="POST">
                                                <div class="row">
                                                    
                                                <input type="hidden" name="Vkey" value="<?= $Vkey; ?>" class="form-control">
                                                <input type="hidden" name="CaseID" value="<?=$Details['CaseID'];?>" class="form-control">
                                                <div class="col-xl-3 col-md-6">
                                                         <label for="">Case No</label>
                                                         <input type="text" name="CaseNo" value="<?=$Details['CaseNo'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-6 col-md-12">
                                                     </div>

                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Date of Complaint</label>
                                                         <input type="text" name="DateComplained" value="<?php echo date('M d, Y', strtotime($timestamp)); ?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">First Name</label>
                                                         <input type="text" name="CFirstName" value="<?=$Details['CFirstName'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">LastName</label>
                                                         <input type="text" name="CLastName" value="<?=$Details['CLastName'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                     <label for="">Email</label>
                                                         <input type="text" name="CEmail" value="<?=$Details['CEmail'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Complainant Category</label>
                                                         <select name="CCategory" id=""class="form-control">
                                                            <option value="">--Select Complainant Category--</option>
                                                            <option value="Senior">Senior</option>
                                                            <option value="PWD">PWD</option>
                                                            <option value="Student">Student</option>
                                                            <option value="Normal Citizen">Normal Citizen</option>
                                                         </select>
                                                     </div>
                                                     <div class="col-xl-12 col-md-12">
                                                         <strong><p class="mt-4">Vehicle Details</p></strong>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Type of Vehicle</label>
                                                         <select id="Vtype" name="VType" id="Vtype" onchange="Code" class="form-control">
                                                            <option value="">--Select Vehicle Type--</option>
                                                            <option value="Private">Private</option>
                                                            <option value="Public">Public</option>
                                                         </select>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Operator Name</label>
                                                         <input type="text" name="VOperatorName" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Plate No</label>
                                                         <input type="text" name="VPlateNo" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Code No (<i>for public vehicle only</i>)</label>
                                                         <input id="Code" type="text" name="VCode" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Vechicle Organization</label>
                                                         <input type="text" name="VOrganization" class="form-control">
                                                     </div>
                                                     <strong><hr class="mt-4 border bg-light"></strong>
                                                     
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Location of Incident</label>
                                                         <input type="text" name="LocIncident" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">From: (<i>for fare matrix concern</i>)</label>
                                                         <input type="text" name="BFrom" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">To: (<i>for fare matrix concern</i>)</label>
                                                         <input type="text" name="BTo" class="form-control">
                                                     </div>
                                                     
                                                     <div class="col-xl-6 col-md-6">
                                                        <label for="">Complaint Details</label>
                                                         <textarea name="CDetails" id="" cols="30" rows="5" class="form-control"><?=$Details['CDetails'];?></textarea>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Proof of Evidence</label>
                                                        <a data-bs-toggle="modal" data-bs-target="#reg-modal">
                                                         <img src="../assets/proof/<?=$Details['CProof'];?>" alt="" height="130px" class="form-control"></a>
                                                     </div>
                                                     
                                                     <div class="col-xl-3 col-md-6">
                                                     <br><br><br><br>
                                                         <button type="submit" name="btnfromupdate" class="btn btn-primary mt-4 float-end" ><i class="fas fa-save"></i> Update</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                </div>
                            </div>
                        </div>

                        </main>
<footer class="bg-light text-center text-lg-start">
         <!-- Copyright -->
         <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
         Copyright &copy; PCMS|POSD <?php $year = date("Y"); echo $year;?>
         </div>
         <!-- Copyright -->
   </footer>


   <script src="assets/js/bootstrap5.bundle.min.js"></script>
   <script src="assets/js/scripts.js"></script>

<script>
      function get_subcategory(){
            var category = $('#category').val();
            $.ajax({
                  url: "ajax.php",
                  type: "POST",
                  data: {category:category},
                  success: function (result){
                        $("#subcategory").html(result);
                  }
            })
      }
</script>
</body>
</html>