<?php
session_start();
include('admin/config/dbcon.php');

if(isset($_POST['btnreg']))
{

    $FirstName = mysqli_real_escape_string($con, $_POST['FirstName']);
    $LastName = mysqli_real_escape_string($con, $_POST['LastName']);
    $Email = mysqli_real_escape_string($con, $_POST['Email']);
    $Password = mysqli_real_escape_string($con, $_POST['Password']);
    $Cpassword = mysqli_real_escape_string($con, $_POST['Cpassword']);
    //Generate Vkey
		$Vkey = md5(time().$FirstName);
		

    if($Password == $Cpassword)
    {
        //check email
        $chkemail = "SELECT Email FROM accounts WHERE email='$Email'";
        $chkemail_run = mysqli_query($con,$chkemail);

        if(mysqli_num_rows($chkemail_run) > 0)
        {
            //Exist
            $_SESSION['message'] = "Email Already Exist";
            header("Location: register.php");
            exit(0);

        }
        else
        {
            $aquery = "INSERT INTO accounts (FirstName,LastName,Email,Password,Vkey) VALUES ('$FirstName','$LastName','$Email','$Password','$Vkey')";
            $aquery_run = mysqli_query($con,$aquery);
            if($aquery_run)
            {
                $_SESSION['message'] = "You may now login";
                header("Location: login.php");
                exit(0);
            }
            else
            {
                $_SESSION['message'] = "Something went wrong!";
                header("Location: register.php");
                exit(0);
            }
        }

    }else
    {
        $_SESSION['message'] = "Please match your password and confirm password";
        header("Location: register.php");
        exit(0);
    }

}
else
{
    header("Location: register.php");
    exit();
}

?>