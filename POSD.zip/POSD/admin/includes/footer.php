
</main>
<footer class="bg-light text-center text-lg-start fixed-bottom">
         <!-- Copyright -->
         <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
         Copyright &copy; PCMS|POSD <?php $year = date("Y"); echo $year;?>
         </div>
         <!-- Copyright -->
   </footer>


   <script src="assets/js/bootstrap5.bundle.min.js"></script>
   <script src="assets/js/scripts.js"></script>

<script>
      function get_subcategory(){
            var category = $('#category').val();
            $.ajax({
                  url: "ajax.php",
                  type: "POST",
                  data: {category:category},
                  success: function (result){
                        $("#subcategory").html(result);
                  }
            })
      }
</script>
</body>
</html>