<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a href="../index.php" class="navbar-brand" accesskey="z">PCMS|POSD</a>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
    </div>
  </div>
</nav>
<main>