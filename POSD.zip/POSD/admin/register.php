<?php
session_start();
if(isset($_SESSION['auth']))
{
    if(!isset($_SESSION['message']))
    {
    $_SESSION['message'] = "You are already login";
    }
    header("Location: index.php");
    exit(0);
}
include('includes/header.php');
include('includes/navbar.php');
?>

<div class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">

                <?php include('message.php'); ?>

                <div class="card">
                    <card class="body">
                        <h4>Sign Up</h4>
                    </card>
                    <div class="card-body">
                        <form action="registrationcode.php" method="POST">
                        <div class="form-group mb-3">
                            <label>First Name</label>
                            <input required type="text" name="FirstName" placeholder="Enter First Name" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label>Last Name</label>
                            <input required type="text" name="LastName" placeholder="Enter Last Name" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label>Email</label>
                            <input required type="email" name="Email" placeholder="Enter Email" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label>Password</label>
                            <input required type="password" name="Password" placeholder="Enter Password" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label>Confirm Password</label>
                            <input required type="password" name="Cpassword" placeholder="Enter Password" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" name="btnreg" class="btn btn-primary">Signup</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('includes/footer.php');
?>