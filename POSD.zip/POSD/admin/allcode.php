<?php
session_start();
include('admin/config/dbcon.php');



if(isset($_POST['btncreatepass']))
{
    $Vkey = $_POST['Vkey'];
    $Address = $_POST['Address'];
    $Email = $_POST['CEmail'];
    $Password = $_POST['Password'];
    $CPassword = $_POST['CPassword'];
    $NPassword = md5($Password);
    $query = "UPDATE accounts SET Address='$Address', Password='$NPassword'WHERE Vkey='$Vkey' ";
    $query_run = mysqli_query($con, $query);
if($Password != $CPassword)
{
    $_SESSION['message'] = "Password and confirmpassword not match";
        header('Location: createpass.php?vkey='.$Vkey);
        exit(0);
}
    else
    {
       
        $_SESSION['message'] = "Your complaint and account is considered as verified please login to monitor your conmplaint. Expect an email or call from us with this day.";
        header('Location: ../index.php');
        exit(0);
    }

}



if(isset($_POST['btnfromupdate']))
{
    $Vkey = $_POST['Vkey'];
    $ID = $_POST['CaseID'];
    $FirstName = $_POST['CFirstName'];
    $Email = $_POST['CEmail'];
    $CaseNo = $_POST['CaseNo'];
    $CCategory = $_POST['CCategory'];
    $VType = $_POST['VType'];
    $VOperatorName = $_POST['VOperatorName'];
    $VPlateNo = $_POST['VPlateNo'];
    $VCode = $_POST['VCode'];
    $VOrganization = $_POST['VOrganization'];
    $LocIncident = $_POST['LocIncident'];
    $BFrom = $_POST['BFrom'];
    $BTo = $_POST['BTo'];
    $CDetails = $_POST['CDetails'];
    $Status = '2';
    $query = "UPDATE complain SET  CaseNo='$CaseNo', CCategory='$CCategory', VType='$VType', VOperatorName='$VOperatorName', VPlateNo='$VPlateNo',VCode='$VCode',VOrganization='$VOrganization',LocIncident='$LocIncident',BFrom='$BFrom',BTo='$BTo', CDetails='$CDetails', Status='$Status' WHERE CaseID='$ID' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Please create your password";
        header('Location: createpass.php?vkey='.$Vkey);

        exit(0);
    }
}

if(isset($_POST['btnlogout']))
{
    //session destroy
    unset($_SESSION['auth']);
    unset($_SESSION['auth_role']);
    unset($_SESSION['auth_user']);

    $_SESSION['message'] = "Logged out successfully";
    header("Location: login.php");
    exit(0);

}
else{

}
if(isset($_POST['btnulogout']))
{
    //session destroy
    unset($_SESSION['auth']);
    unset($_SESSION['auth_role']);
    unset($_SESSION['auth_user']);

    $_SESSION['message'] = "Logged out successfully";
    header("Location: ../index.php");
    exit(0);

}

if(isset($_POST['btnnewsupdate']))
{   
    $NewsID = $_POST['NewsID'];
    $Title = $_POST['Title'];
    $Status = $_POST['Status'];
    
    $OldFileName =$_POST['OldFileName'];  
    $Image = $_FILES['Image']['name'];
    $UpdateFileName = "";
    $path = "../assets/news/";

    if($Image != NULL)
    {
    $image_extension = pathinfo($Image, PATHINFO_EXTENSION);
    $FileName = time().'.'.$image_extension;
    $UpdateFileName = $FileName;
    }
    else
    {
    $UpdateFileName = $OldFileName;
    }

    $query = "UPDATE news SET Title='$Title', status='$Status', Image='$UpdateFileName' WHERE NewsID='$NewsID'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        if($Image != NULL)
        {
            if(file_exists($path."/".$OldFileName)){
                unlink($path."/".$OldFileName);
            }
        move_uploaded_file($_FILES['Image']['tmp_name'], $path."/".$UpdateFileName);
        }
        $_SESSION['message'] = "Updated successfully";
        header('Location: admin/view-news.php?id='.$NewsID);
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Something went wrong!";
        header('Location: admin/view-news.php?id='.$NewsID);
        exit(0);
    }
}



if (isset($_POST['btnsignup'])){
	
	//Get Form Data
	
	$FirstName = $_POST['FirstName'];
	$LastName = $_POST['LastName'];
	$Email = $_POST['Email'];
	$Password = $_POST['Password'];
	$CPassword = $_POST['CPassword'];
	$Address = $_POST['Address'];
	$Mobile = $_POST['Mobile'];
    $chkmail = "SELECT 1 FROM accounts WHERE Email = '$Email'";
    $chkmailrun = mysqli_query($con, $chkmail);
    if(mysqli_num_rows($chkmailrun) > 0)
    {
        $_SESSION['message'] = "Email already exist please use other email!";
        header('Location: ../index.php');
		exit(0);
    }
	elseif ($Password != $CPassword){
		$_SESSION['message'] = "Password and confirm Password not match!";
        header('Location: ../index.php');
		exit(0);
		
	}else{
		
		//Generate Vkey
		$Vkey = md5(time().$FirstName);
		
		//Insert to database
		$Password = md5($Password);
		$Insert = "INSERT INTO accounts (FirstName,LastName,Email,Password,Address,Mobile,Vkey) VALUES ('$FirstName','$LastName','$Email','$Password','$Address','$Mobile','$Vkey')";
        $Insertrun = mysqli_query($con, $Insert);
		
		if($Insertrun){
            $_SESSION['message'] = "Registration success, Please validate your email!";
			
			//send email
            $to = $Email;
			$Subject = "Account Verification Process";
			$Message=" Hi $FirstName<br>
            <p>please verify your account by clicking the url below.</p><br><br>
            <a href='http://localhost:8080/posd/php/rverify.php?vkey=$Vkey'>Click here to verify</a><br><br><br>
            
            Thank you!<br><br>
            POSD Cauayan
            <p><i><b>Note:</b>
            This process is designed to reduce fake complaints and users trying out our innovative technology. so please follow the process correctly for the benefit of our new system and that we can respond quickly to your complaint</i></p><br>
            <p><i>This email message (including attachments, if any) is intended for the use of the individual or the entity to whom it is addressed and may contain information that is privileged, proprietary, confidential and exempt from disclosure. If you are not an intended recipient of this e-mail, you are not authorized to duplicate, copy, retransmit, or redistribute it by any means. Please delete it and any attachments immediately and notify the sender that you have received it in error.</i></p>";
			$headers ="From: cauayanposd@gmail.com \r\n";
			$headers .="MTME-Version: 1.0" ."\r\n";
			$headers .="Content-type:text/html;charset-UTF-8" . "\r\n";
			mail($to,$Subject,$Message,$headers);
            $_SESSION['message'] = "Registration successfully we send and email verification!";
            header('Location: ../index.php');
            exit(0);
		}
		else{
			$_SESSION['message'] = "Something went wrong please check your details!";
            header ('Location: ../index.php');
			exit(0);
			}
	
	
	}
}




?>