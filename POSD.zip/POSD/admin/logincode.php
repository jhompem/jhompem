<?php
session_start();
include('admin/config/dbcon.php');

if(isset($_POST['btnlogin']))
{
    $Email = mysqli_real_escape_string($con, $_POST['Email']);
    $Password = mysqli_real_escape_string($con, $_POST['Password']);
    $Password = md5($Password);
    $lquery = "SELECT * FROM accounts WHERE Email = '$Email' AND Password = '$Password'";
    $lquery_run = mysqli_query($con, $lquery);
    

    if (mysqli_num_rows($lquery_run) > 0)
    {
        foreach($lquery_run as $data)
        {
            $UserID = $data['UserID'];
            $UFullName = $data['FirstName']. ' ' .$data['LastName'];
            $UEmail = $data['Email'];
            $Ulevel = $data['UserLevel'];

        }

        $_SESSION['auth'] = true;
        $_SESSION['auth_role'] = $Ulevel; //0=admin 1=user 2=superadmin
        $_SESSION['auth_user'] = [
            'UserID' =>$UserID,
            'UFullName' =>$UFullName,
            'UEmail' => $UEmail,
        ];

        if($_SESSION['auth_role'] == '0')
        {
        $_SESSION['message'] = "Welcome to POSD Dashboard";
        header("Location: admin/index.php");
        exit(0);
        }
        elseif($_SESSION['auth_role'] == '2')
        {
        $_SESSION['message'] = "Welcome to POSD Dashboard";
        header("Location: admin/index.php");
        exit(0);
        }
        elseif($_SESSION['auth_role'] == '1')
        {
        
        unset($_SESSION['auth']);
        unset($_SESSION['auth_role']);
        unset($_SESSION['auth_user']);
        $_SESSION['message'] = "Your not authorized to that page";
        header("Location: ../index.php");
        exit(0);
        }
        else
        {
        unset($_SESSION['auth']);
        unset($_SESSION['auth_role']);
        unset($_SESSION['auth_user']);
        $_SESSION['message'] = "Please register an account";
        header("Location: ../index.php");
        }

    }

    else
    {
        $_SESSION['message'] = "Invalid Email or Password";
        header("Location: Login.php");
        exit(0);

    }

}
else
{
            $_SESSION['message'] = "You dont have access on that page";
            header("Location: ../index.php");
            exit(0);
}

?>