<?php
session_start();
include('admin/config/dbcon.php');

if(isset($_POST['btnlogin']))
{
    $Email = mysqli_real_escape_string($con, $_POST['Email']);
    $Password = mysqli_real_escape_string($con, $_POST['Password']);
    $Password = md5($Password);
    $lquery = "SELECT * FROM accounts WHERE Email = '$Email' AND Password = '$Password' AND Verified = '1'";
    $lquery_run = mysqli_query($con, $lquery);
    $lquery1 = "SELECT * FROM accounts WHERE Email = '$Email' AND Password = '$Password' AND Verified != '1'";
    $lquery1_run = mysqli_query($con, $lquery1);

    if (mysqli_num_rows($lquery_run) > 0)
    {
        foreach($lquery_run as $data)
        {
            $UserID = $data['UserID'];
            $UFullName = $data['FirstName']. ' ' .$data['LastName'];
            $UEmail = $data['Email'];
            $Ulevel = $data['UserLevel'];
            $UVkey = $data['Vkey'];

        }

        $_SESSION['auth'] = true;
        $_SESSION['auth_role'] = $Ulevel; //0=admin 1=user 2=superadmin
        $_SESSION['auth_vkey'] = $Verified; // 0= not verified 1=verified
        $_SESSION['auth_user'] = [
            'UserID' =>$UserID,
            'UFullName' =>$UFullName,
            'UEmail' => $UEmail,

        ];
        $_SESSION['key'] = $UVkey;
        if($_SESSION['auth_role'] == '1')
        {
            $_SESSION['message'] = "You may now file a report and monitor it!";
            header("Location: ../index.php");
            exit(0);
        }
        else
        {
            unset($_SESSION['auth']);
            unset($_SESSION['auth_role']);
            unset($_SESSION['auth_user']);
            $_SESSION['message'] = "Admin has seperate portal, Please Go to your portal!";
            header("Location: ../index.php");
            exit(0);
        }
    }
    elseif(mysqli_num_rows($lquery1_run) > 0)
    {
        $_SESSION['message'] = "Please Verify your account before login we sent you an Email verification after your registration";
        header('Location: ../index.php');
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Please check your Email or Password";
        header("Location: ../index.php");
        exit(0);
    }
    
    
}
 

?>