<?php
session_start();
include('../admin/admin/config/dbcon.php');

?>
                                    <div class="table-resposive">
                                         <table class="table table-bordered mt-4">
                                                <thead>
                                                    <tr>
                                                        <th>Case No</th>
                                                        <th>Purpose</th>
                                                        <th>Sender of update</th>
                                                        <th>Date Sent</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    
                                                    $CaseNo = $_POST['userid'];
                                                    
                                        echo $CaseNo;
                                                    $query = "SELECT * FROM message WHERE CaseNo = '$CaseNo' ORDER BY DateSent DESC";
                                                    $query_run = mysqli_query($con, $query);

                                                    if(mysqli_num_rows($query_run) > 0)
                                                    {

                                                        foreach($query_run as $row)
                                                        {
                                                            $timestamp = $row['DateSent'];
                                                            ?>
                                                    <tr>
                                                        <td><?= $row['CaseNo'];?></td>
                                                        <td><?= $row['Purpose']; ?></td>
                                                        <td><?= $row['Sender']; ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($timestamp)); ?></td>
                                                       
                                                    </tr>

                                                            <?php
                                                        }

                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        <td colspan="4">It may not have been noticed by one of our staff please wait a few more minutes</td>
                                                        <?php
                                                    }
                                               

                                                    ?>
                                                    
                                                </tbody>
                                            </table>
                                            </div>