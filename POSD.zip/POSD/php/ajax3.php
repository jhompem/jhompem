<?php

session_start();
include('../admin/admin/config/dbcon.php');

$sql= "SELECT * FROM faqs";
$sqlrun = mysqli_query($con, $sql);
if(mysqli_num_rows($sqlrun) > 0)
{
foreach($sqlrun as $row)
{                                         
?>

<div class="container">
    <div class="row">
        <div class="col-xl-12">
       <h2><?=$row['Question'];?></h2>
        <p><?=$row['Answer'];?></p>
        <hr>
        </div>
    </div>
</div>
<?php
}
}
 else
 {
                ?>
                echo 'No Record Found';
                <?php
                }
                ?>  