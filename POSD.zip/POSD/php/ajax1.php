<?php

session_start();
include('../admin/admin/config/dbcon.php');

$OrID = $_POST['userid'];
$sql= "SELECT * FROM ordinance WHERE OrID = $OrID";
$sqlrun = mysqli_query($con, $sql);
if(mysqli_num_rows($sqlrun) > 0)
{
foreach($sqlrun as $row)
{                                         
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-xl-12">
        <img class="img-fluid" src="assets/ordinance/<?=$row['Image'];?>" height="100px"/>
        <hr>
        <br>
        <h3 class="text-center"><?=$row['Title'];?></h3>
        <p class="text-center fs-6"><i><?=$row['OrdinanceNo'];?></i></p>
        
        <br>
        <p style="text-indent: 60px;"><?=$row['Description'];?></p>
        </div>
    </div>
</div>
<?php
}
}
 else
 {
                ?>
                echo 'No Record Found';
                <?php
                }
                ?>  