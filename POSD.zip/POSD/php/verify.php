<?php
session_start();
include('../admin/admin/config/dbcon.php');

if (isset($_GET['vkey'])){
	//process Verification
	$Vkey = $_GET['vkey'];
	
	$query = "SELECT Verified,Vkey FROM accounts WHERE Verified = 0 AND Vkey = '$Vkey' LIMIT 1";
    $query_run = mysqli_query($con, $query);
        if(mysqli_num_rows($query_run) > 0)
        {

			$Update = "UPDATE accounts SET Verified = 1 WHERE Vkey = '$Vkey' LIMIT 1";
			$Update_run = mysqli_query($con, $Update);

			if($Update_run)
			{
			$_SESSION['message'] = "your account hase been verified please complete the details of complaint form.";
            header('Location: ../admin/complainform.php?vkey='.$Vkey);
            exit(0);
			}
			else
			{
				echo $Mysqli->error;
			}
		
		}
		else
		{
			$_SESSION['message'] = "This account invalid or already verified";
            header('Location: ../index.php');
            exit(0);
		}
        
       
}
else
{
		$_SESSION['message'] = "Something went wrong!";
		header('Location: ../index.php');
		exit(0);
}
?>
