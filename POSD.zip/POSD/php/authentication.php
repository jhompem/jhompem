<?php
session_start();
include('admin/admin/config/dbcon.php');

if($_SESSION['auth_role'] != "1")
    {
        $_SESSION['message'] = "That page is for landing page purposses only please use your account correctly";
        header("Location: admin/admin/index.php");
        exit(0);

    }

?>