<h3 class="text-center">Signup</h3>
                                    <div class="form-group">
                                        
                                        <form method="POST" action="admin/allcode.php" action="" align="center">
                                        <div class="form-group mb-3">
                                                    <input name="FirstName" type="text" size="32" maxlength="15" minimum="1" placeholder="First Name" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required/>
                                                </div>
												<div class="form-group mb-3">
													<input name="LastName" type="text" value="" size="32" maxlength="15" placeholder="Last Name" class="form-control" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required/></td>
                                                </div>
                                                <div class="form-group mb-3">
                                                    <input type="text" name="Address" value="" size="32" placeholder="Address (Brgy., Purok, Street, Lot, Block & House Number" class="form-control" required/>
                                                </div>
                                                 <div class="form-group mb-3">
                                                    <input type="email" name="Email" value="" size="32" placeholder="Email" class="form-control" required/>
                                                </div>
												<div class="form-group mb-3">
													<input type="text" name="Mobile" value="" size="32" placeholder="Phone Number (09*********)" class="form-control" pattern="^[+]?[\d]+([\-][\d]+)*\d$" minlength="11" title="Must start with [09 / +63] and at least 11 digit number to 13 with area code" required/></td>
                                                </div>
                                                <div class="form-group mb-3">
                                                    <input type="password" name="Password" value="" size="32" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letterand one symbol, and at least 8 or more characters" placeholder="Password" class="form-control"required/>
                                                </div>
												<div class="form-group mb-3">
													<input type="password" name="CPassword" value="" size="32" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letterand one symbol, and at least 8 or more characters" placeholder="Confirm Password" class="form-control" required/></td>
                                                </div>
                                                <div class="form-group mb-3">
													<input name="btnsignup"type="submit" value="Sign Up" class="btn btn-primary w-100"/>
                                               </div>
                                               
                                            
                                        </form>