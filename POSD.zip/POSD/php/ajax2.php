
<h3 class="text-center">Log In</h3>
                             
<form action="admin/logincodeuser.php" method="POST" autocomplete="on">
<div class="form-group mb-3">
<input focus required type="email" name="Email" placeholder="Enter Email" class="form-control" minlength="2" pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$" title = "Please input a valid email format eg. cauayan@isabela.com" required>
</div>
<div class="form-group mb-3">
<input required type="password" name="Password" placeholder="Enter Password" class="form-control" minlength="8" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number [1-0] and one uppercase [A-Z] and lowercase [a-z] letter and one symbol [*!#], and at least 8 or more characters" required>
</div>
<div class="form-group mb-3">
<button type="submit" name="btnlogin" class="btn btn-primary w-100">Login</button>
</div>
</form>
                                