<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_DBPOSD = "localhost";
$database_DBPOSD = "posd";
$username_DBPOSD = "root";
$password_DBPOSD = "";
$DBPOSD = mysql_pconnect($hostname_DBPOSD, $username_DBPOSD, $password_DBPOSD) or trigger_error(mysql_error(),E_USER_ERROR); 
?>