<?php
include('admin/admin/config/dbcon.php');
session_start();


if(isset($_POST['btnreport']))
{
	$FirstName = $_POST['FirstName'];
	$LastName = $_POST['LastName'];
	$Email = $_POST['Email'];
	$Mobile = $_POST['Mobile'];
	$ComplaintDetails = $_POST['ComplaintDetails'];

    $CProof = $_FILES['CProof']['name'];
    $path = "assets/proof/"; 
    $image_extension = pathinfo($CProof, PATHINFO_EXTENSION);
    $filename = time().'.'.$image_extension;

    $Vkey = $Vkey = md5(time().$FirstName);
    $Password = $Password = (time());
    
    $query = "INSERT INTO complain (CFirstName,CLastName,CEmail,CMobile,CDetails,CProof,Vkey) VALUES ('$FirstName','$LastName','$Email','$Mobile','$ComplaintDetails','$filename','$Vkey')";
    $query_run = mysqli_query($con, $query);
    $query1 = "INSERT INTO accounts (FirstName,LastName,Email,Password,Mobile,Vkey) VALUES ('$FirstName','$LastName','$Email','$Password','$Mobile','$Vkey')";
    $query1_run = mysqli_query($con, $query1);


        if($query_run && $query1_run)
        {
            $lastcase = mysqli_insert_id($con);
            if($lastcase)
            {   $year = date("Y");
                $Code = rand(1,99999);
                $CaseNo = $year."-". $Code;
                $querycode = "UPDATE complain SET CaseNo = '$CaseNo' WHERE Vkey = '$Vkey'";
                $res = mysqli_query($con, $querycode);
            }

            move_uploaded_file($_FILES['CProof']['tmp_name'], $path."/".$filename);
            
            $to = $Email;
			$Subject = "Report and Account Verification Process";
			$Message=" Hi $FirstName<br>
            <p>Your complaint has been received, please verify that your concern is really happened by clicking the url below and follow the process.</p><br><br>
            <a href='http://localhost:8080/posd/php/verify.php?vkey=$Vkey'>Click here to verify</a><br><br><br>
            
            Thank you!<br><br>
            POSD Cauayan
            <p><i><b>Note:</b>
            This process is designed to reduce fake complaints and users trying out our innovative technology. so please follow the process correctly for the benefit of our new system and that we can respond quickly to your complaint</i></p><br>
            <p><i>This email message (including attachments, if any) is intended for the use of the individual or the entity to whom it is addressed and may contain information that is privileged, proprietary, confidential and exempt from disclosure. If you are not an intended recipient of this e-mail, you are not authorized to duplicate, copy, retransmit, or redistribute it by any means. Please delete it and any attachments immediately and notify the sender that you have received it in error.</i></p>";
			$headers ="From: cauayanposd@gmail.com \r\n";
			$headers .="MTME-Version: 1.0" ."\r\n";
			$headers .="Content-type:text/html;charset-UTF-8" . "\r\n";
			mail($to,$Subject,$Message,$headers);
            $_SESSION['message'] = "Reported successfully we send and email verification to confirm your reported concern";
            header('Location: index.php#page-top');
            exit(0);
        
        }

        else
        {
            $_SESSION['message'] = "Somethine went wrong!";
            header('Location: index.php#page-top');
            exit(0);
        }

}



if(isset($_POST['btnddcomplaint']))
{
    
    $FirstName = $_POST['CFirstName'];
    $LastName = $_POST['CLastName'];
    $Email = $_POST['CEmail'];
    $Mobile = $_POST['CMobile'];
    $CCategory = $_POST['CCategory'];
    $VType = $_POST['VType'];
    $VOperatorName = $_POST['VOperatorName'];
    $VPlateNo = $_POST['VPlateNo'];
    $VCode = $_POST['VCode'];
    $VOrganization = $_POST['VOrganization'];
    $LocIncident = $_POST['LocIncident'];
    $BFrom = $_POST['BFrom'];
    $BTo = $_POST['BTo'];
    $Details = $_POST['CDetails'];
   
    $CProof = $_FILES['CProof']['name'];
    $path = "assets/proof/"; 
    $image_extension = pathinfo($CProof, PATHINFO_EXTENSION);
    $filename = time().'.'.$image_extension;

    $year = date("Y");
    $Code = rand(1,99999);
    $CaseNo = $year."-". $Code;
    $Vkey = $_SESSION['key'];
    $Status = '2';

    $queryadd = "INSERT INTO complain (CaseNo,CFirstName,CLastName,CEmail,CCategory,CMobile,VType,VCode,VPlateNo,VOperatorName,VOrganization,LocIncident,BFrom,BTo,CDetails,CProof,Status,Vkey) VALUES ('$CaseNo','$FirstName','$LastName','$Email','$CCategory','$Mobile','$VType','$VCode','$VPlateNo','$VOperatorName','$VOrganization','$LocIncident','$BFrom','$BTo','$Details','$filename','$Status','$Vkey')";
    $queryadd_run = mysqli_query($con, $queryadd);

        if($queryadd_run)
        {
            
            move_uploaded_file($_FILES['CProof']['tmp_name'], $path."/".$filename);
            
            $_SESSION['message'] = "Reported successfully";
            header('Location: index.php');
            $lastcase = mysqli_insert_id($con);
            exit(0);
        
        }
        else
        {
            $_SESSION['message'] = "Somethine went wrong!";
            header('Location: index.php');
            exit(0);
        }

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head lang="en">
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Public Orders & Safety Division</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/logo.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css?v=<?php echo time();?>" rel="stylesheet" />
    </head>
<body id="page-top">

       <!-- Navigation-->
       <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
  <div class="container">
  <a href="#page-top"><img class="logo"src="assets/img/logo.png" alt="..." /></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
        <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
        <li class="nav-item"><a class="nav-link" href="#ordinance">Ordinance</a></li>
        <li class="nav-item"><a class="nav-link" href="#procedure">Procedure</a></li>
        <li class="nav-item"><a class="faqinfo nav-link" href="#FAQs">FaQ</a></li>
        <?php if(isset($_SESSION['auth_user']) && (isset($_SESSION['auth_role'])== '1')): ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          <?= $_SESSION['auth_user']['UFullName']; ?><i class="fas fa-user fa-fw"></i>
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li>
                <form action="admin/allcode.php" method="POST">
                    <button type="submit" name="btnulogout" class="dropdown-item">Logout</button>
                </form>
            </li>
            
          </ul>
        </li>
        <?php else: ?>
        <li class="nav-item"><a class="logininfo btn btn-secondary">Log In</a></li>
	<li class="nav-item"><a class="signupinfo btn btn-info">Sign Up</a></li>
        <?php endif ?>
      </ul>
    </div>
  </div>
</nav>
        <!-- Masthead-->
        <header class="masthead">
            <a href="admin/login.php" accesskey="l"></a>
            <div class="container">
				<br>
				<br>
				<br>
                
                <?php include('admin/admin/message.php'); ?>
                <?php if(isset($_SESSION['auth_user']) && (isset($_SESSION['auth_role'])== '1')): ?>
                    <div class="masthead-subheading">Monitor your complaint peacefully and without fear!</div>
                    
                    <?php else:?>
                        
                <div class="masthead-subheading">Do you see or experience any violations?</div>
                <a class="btn btn-primary btn-xl text-uppercase" href="#report">Report Now!</a>
              <?php endif ?>
            </div>
        </header>
        

        <?php if(isset($_SESSION['auth_user']) && (isset($_SESSION['auth_role'])== '1')): ?>
<section class="page-section" id="tab">
<div class="container">
    <div class="row">
        <div class="col-md-12">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">

                            <button class="nav-link active" id="nav-complaint-tab" data-bs-toggle="tab"
                            data-bs-target ="#complaint" type="button" role="tab" aria-controls="nav-complaint" aria-selected = "true">Complaint</button>
                          
                            <button class="nav-link" id="nav-form-tab" data-bs-toggle="tab"
                            data-bs-target ="#form" type="button" role="tab" aria-controls="nav-form" aria-selected = "false">Forms</button>
                    </div>
                </nav>
                <div class="tab-content" id="nav-tabcontent">

                        <div class="tab-pane fade show active p-3" id="complaint" role="tabpanel" aria-labelledby="nav-complaint-tab">
                        
                        <div class="table-responsive">
                                         <table id="tblcomp" class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        
                                                        <th>View</th>
                                                        <th>CaseNo</th>
                                                        <th>Date of Complaint</th>
                                                        <th>Officer In Charge</th>
                                                        <th>Date Respond</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php
                                                    $query = "SELECT * FROM complain WHERE Vkey = '".$_SESSION['key']."' ";
                                                    $query_run = mysqli_query($con, $query);

                                                    if(mysqli_num_rows($query_run) > 0)
                                                    {
                                                        foreach($query_run as $row)
                                                        {
                                                            $timestamp = $row['DateComplained'];
                                                            $timestamps = $row['DateRespond'];
                                                            ?>

                                                    <tr>
                                                        <td>
                                                            <button data-id='<?php echo $row['CaseNo'];?>' class="userinfo btn btn-success">info</button>
                                                        </td>
                                                        <td><?= $row['CaseNo']; ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($timestamp)); ?></td>
                                                        <td><?= $row['ROfficer']; ?></td>
                                                        <td>
                                                        <?php
                                                            if(empty($timestamps))
                                                            {
                                                                $timestamps = '';
                                                            }
                                                            else
                                                            {
                                                            echo date('M d, Y', strtotime($timestamps)); 
                                                            }
                                                        ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                            if($row['Status'] == '2')
                                                            {
                                                                echo 'Open';
                                                            }
                                                            elseif ($row['Status'] == '3')
                                                            {
                                                                echo 'Closed';
                                                            }
                                                            else
                                                            {
                                                                echo 'Undifined';
                                                            }
                                                            ?>
                                                            
                                                        </td>
                                                    </tr>  
                                                    <?php
                                                        }

                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        <td colspan="8">No complaints have been recorded</td>
                                                        <?php
                                                    }

                                                    ?>
                                                </tbody>
                                            </table>

                                            <script type ="text/javascript">
	  
                                                $(document).ready(function(){
                                                    $('.userinfo').click(function(){
                                                        var userid = $(this).data('id');
                                                        $.ajax({
                                                        url:"php/ajax.php",
                                                        method:'post',
                                                        data:{userid:userid},
                                                        success:function(response){
                                                            $('.modal-body').html(response);
                                                            $('#infoModal').modal('show');
                                                        
                                                        }
                                                        
                                                    })
                                                    })
                                                    
                                                })
                                                
                                                </script>
                                        </div>
                                            </div>
                       
                        <div   div class="tab-pane fade p-3" id="form" role="tabpanel" aria-labelledby="nav-form-tab">
                           
<div class="container-fluid px-4">
                      
                        <div class="row">
                            
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                    
                                        <h4>Complaint Form</h4>
                                        <p>
                                            <i>
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Note:</b>
                                                This process is designed to reduce fake complaints and users trying out our innovative technology. so please follow the process correctly for the benefit of our new system and that we can respond quickly to your complaint
                                            </i>
                                        </p>
            
                                    </div>
                                        <div class="card-body">
                                        <?php
                                                $CDetails = "SELECT * FROM accounts WHERE Vkey= '".$_SESSION['key']."' ";
                                                $CDetails_run = mysqli_query($con, $CDetails);
                                                if(mysqli_num_rows($CDetails_run) > 0)
                                                {    
                                                    foreach($CDetails_run as $Details)
                                                    {
                                                    ?>
                                            <form action="" method="POST" enctype="multipart/form-data">
                                                <div class="row">
                                                
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">First Name</label>
                                                         <input type="text" name="CFirstName" value="<?=$Details['FirstName'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">LastName</label>
                                                         <input type="text" name="CLastName" value="<?=$Details['LastName'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                     <label for="">Email</label>
                                                         <input type="text" name="CEmail" value="<?=$Details['Email'];?>" class="form-control" readonly>
                                                     </div> <div class="col-xl-3 col-md-6">
                                                     <label for="">Mobile Number</label>
                                                         <input type="text" name="CMobile" value="<?=$Details['Mobile'];?>" class="form-control" readonly>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Complainant Category</label>
                                                         <select name="CCategory" id=""class="form-control">
                                                            <option value="">--Select Complainant Category--</option>
                                                            <option value="Senior">Senior</option>
                                                            <option value="PWD">PWD</option>
                                                            <option value="Student">Student</option>
                                                            <option value="Normal Citizen">Normal Citizen</option>
                                                         </select>
                                                     </div>
                                                     <div class="col-xl-12 col-md-12">
                                                         <strong><p class="mt-4">Vehicle Details</p></strong>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                         <label for="">Type of Vehicle</label>
                                                         <select id="Vtype" name="VType" id="Vtype" onchange="Code" class="form-control">
                                                            <option value="">--Select Vehicle Type--</option>
                                                            <option value="Private">Private</option>
                                                            <option value="Public">Public</option>
                                                         </select>
                                                     </div>
                                                     <div class="col-xl-12 col-md-6">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Operator Name</label>
                                                         <input type="text" name="VOperatorName" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Plate No</label>
                                                         <input type="text" name="VPlateNo" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Code No (<i>for public vehicle only</i>)</label>
                                                         <input id="Code" type="text" name="VCode" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Vechicle Organization</label>
                                                         <input type="text" name="VOrganization" class="form-control">
                                                     </div>
                                                     <strong><hr class="mt-4 border bg-light"></strong>
                                                     
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Location of Incident</label>
                                                         <input type="text" name="LocIncident" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">From: (<i>for fare matrix concern</i>)</label>
                                                         <input type="text" name="BFrom" class="form-control">
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">To: (<i>for fare matrix concern</i>)</label>
                                                         <input type="text" name="BTo" class="form-control">
                                                     </div>
                                                     
                                                     <div class="col-xl-6 col-md-6">
                                                        <label for="">Complaint Details</label>
                                                         <textarea name="CDetails" id="" cols="30" rows="5" class="form-control"></textarea>
                                                     </div>
                                                     <div class="col-xl-3 col-md-6">
                                                        <label for="">Proof of Evidence</label>
                                                        <input type="file" name="CProof" value="" class="form-control"/>
                                                     </div>
                                                     
                                                     <div class="col-xl-3 col-md-6">
                                                     <br><br><br><br>
                                                         <button type="submit" name="btnddcomplaint" class="btn btn-primary mt-4 float-end" ><i class="fas fa-save"></i> Submit</button>
                                                     </div>
                                                </div>
                                            </form>
                                            <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            ?>
                                        </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        

                </div>
        </div>
    </div>
</div>

</section>
<?php endif ?>


</div>      

        <!-- about-->
<section class="page-section" id="about">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-4">
						<h2 class="my-3">Mission</h2> 
						<p>
						We will be the Ideal City of the North by living up the following</br>
                        *Melting pot of rich and divert cultures</br>
                        *Center for economic progress and sustainable development</br>
                        *Eco-friendly, innovative and God-center community</br>
                        *Honest government equally collaborating with the empowered people and private sector</br>
                        </p>
						
                    </div>
                    <div class="col-md-4">
                    <h2 class="my-3">Vision</h2>
                        <p>The Ideal City of the North.
                        </p>
                    </div>
                    <div class="col-md-4">
						<h2 class="my-3">QUALITY POLICY</h2>
                        <p>The City Government of Cauayan, Isabela commits to provide prompt, accessible, and quality services to the People of Cauayan in the field of Cultural, Economics, Social, Environment, and Local Administrative delivered with Integrity, Competence, Honesty, Transparency, and accountability, thus making the City of Cauayan, Isabela the Ideal City of the North.</br>
                        <p>To strengthen this culture of good governance, we shall maintain an internationally accredited Quality Management System based on the requirements of ISO 90001:2015 and continuously improve its effectiveness through regular monitoring review and auditing</p>

                        </p>
                    </div>

                <!-- News Section upload image 450px x 380px-->
                    <div class="col-md-4">

                    <?php 
                        $newsres = $con->query("SELECT Image FROM news WHERE status='0' ORDER BY NewsID DESC");
                    ?>

                    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">

                            <div class="carousel-indicators">
                                <?php
                                    $i = 0;
                                    foreach ($newsres as $row) {
                                        $actives = '';
                                        if($i == 0){
                                            $actives = 'active';
                                        
                                    }
                                ?>
                                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="<?= $i; ?>" class="<?= $actives; ?>" aria-current="true" aria-label="Slide 1"></button>
                                <?php 
                                    $i++;
                                }
                                ?>

                                </div>
                            <div class="carousel-inner">
                                <?php
                                        $i = 0;
                                        foreach ($newsres as $row) {
                                            $actives = '';
                                            if($i == 0){
                                                $actives = 'active';
                                            
                                        }
                                    ?>
                                <div class="carousel-item <?= $actives; ?>">
                                  <img src="assets/news/<?= $row['Image'];?>" class="d-block w-100" height="380px">
                                <div class="carousel-caption d-none d-md-block">
                                </div>
                                </div>
                                <?php
                                $i++;
                                    }
                                ?>
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        
        <!-- ordinance-->
<section class="page-section bg-light" id="ordinance">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Municipal Ordinance</h2>
					<br>
                </div>
                <div class="row">
                <?php
                $query = "SELECT * FROM ordinance";
                $query_run = mysqli_query($con, $query);

                if(mysqli_num_rows($query_run) > 0)
                {
                foreach($query_run as $row)
                {                                         
                ?>
                <div class="col-lg-4 col-sm-6 mb-4">
                        <div class="portfolio-item">
                            <a  data-id='<?php echo $row['OrID'];?>' class="orinfo portfolio-link">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="assets/ordinance/<?=$row['Image'];?>" height="100px"/>
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading"><?=$row['Title'];?></div>
                                <div class="portfolio-caption-subheading text-muted"><?=$row['OrdinanceNo'];?></div>
                            </div>
                        </div>
                    </div>
                <?php
                }
                }
                else
                {
                ?>
                echo 'No Record Found';
                <?php
                }
                ?>     
                </div>
            </div>
</section>



        <!-- procedure-->
<section class="page-section" id="procedure">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Current Investigation Procedure&nbsp;</h2>
                    <h3 class="section-subheading text-muted">The procedure is for all complainant of abusive tricycle drivers.</h3>
                </div>
                <ul class="timeline">
                    <li>
                        <div class="timeline-image"><i class="fa fa-edit fa-4x mx-auto d-block mt-5"></i></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Step 1</h4>
                                <h4 class="subheading">fill-up the complainant form</h4>
                            </div>
                            <div class="timeline-body">
                                <p class="text-muted">
                                    Responsible Person: Complainant</br>
                                    Progressing Time: 1 min</br>
                                    Form needed: Complainant Form
                                </p>
                            </div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><i class="fa fa-share fa-4x mx-auto d-block mt-5"></i></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Step 2</h4>
                                <h4 class="subheading">Complain will be forwarded to all unit</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">
                            The POSD Investigator will call the attention of all POSD Members in the field through portable radio to apprehend the tricycle driver through his body number.</br>
                           </br>
                            Progressing Time: 1 min</br>
                            </p>
                        </div>
                        </div>
                    </li>
                    <li>
                        <div class="timeline-image"><i class="fa fa-search fa-4x mx-auto d-block mt-5"></i></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Step 3</h4>
                                <h4 class="subheading">Investigation</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">If the tricycle driver was apprehended, the investigation will be conducted.</br>
                            </br>
                            Progressing Time: 3-5 mins</br>
                            Form Needed: Traffic Offence ticket
                            </p>
                        </div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><i class="fa fa-handshake fa-4x mx-auto d-block mt-5"></i></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Step 4</h4>
                                <h4 class="subheading">Setlement</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">
                                    Shall settle the said complaint.</br>
                                   </br>
                                    Progressing Time: 2-3 mins</br>
                                    Form needed: Complainant Form
                                </p>
                                </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image">
                            <p><i class="fa fa-flag fa-4x mx-auto d-block mt-4"></i>Finish</p>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
        <!-- Count stats -->
        <div class="py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-3 col-sm-6 my-3">
                    <div class="card bg-primary text-white mb-4 text-center">
                    <div class="card-body mx-auto">Total Complaint
                    <?php
                                            $dash_complainant = "SELECT * FROM complain";
                                            $dash_complainant_run = mysqli_query($con, $dash_complainant);
                                            $complaint = mysqli_num_rows($dash_complainant_run);
                                            if($comptotal = mysqli_num_rows($dash_complainant_run))
                                            {
                                                echo ' <h1 class="mb-0">'.$comptotal.'</h1>';
                                            }
                                            else
                                            {
                                                echo ' <h1 class="mb-0">0</h1>';
                                            }
                                        ?>
                    </div>
                    </div>
                    </div>
                    <div class="col-md-3 col-sm-6 my-3">
                    <div class="card bg-primary text-white mb-4 text-center">
                    <div class="card-body mx-auto">Total Closed Complaint
                    <?php
                                            $dash_undi = "SELECT * FROM complain WHERE status='3'";
                                            $dash_undi_run = mysqli_query($con, $dash_undi);

                                            if($tundi = mysqli_num_rows($dash_undi_run))
                                            {
                                                echo ' <h1 class="mb-0">'.$tundi.'</h1>';
                                            }
                                            else
                                            {
                                                echo ' <h1 class="mb-0">0</h1>';
                                            }
                                        ?>
                    </div>
                    </div>
                    </div>
                    <div class="col-md-3 col-sm-6 my-3">
                    <div class="card bg-primary text-white mb-4 text-center">
                    <div class="card-body mx-auto">Total Undefined
                    <?php
                                            $dash_opem = "SELECT * FROM complain WHERE status='1'";
                                            $dash_open_run = mysqli_query($con, $dash_opem);

                                            if($topen = mysqli_num_rows($dash_open_run))
                                            {
                                                echo ' <h1 class="mb-0">'.$topen.'</h1>';
                                            }
                                            else
                                            {
                                                echo ' <h1 class="mb-0">0</h1>';
                                            }
                                        ?>
                    </div>
                    </div>
                    </div>
                    <div class="col-md-3 col-sm-6 my-3">
                    <div class="card bg-primary text-white mb-4 text-center">
                    <div class="card-body mx-auto">Total Open Complaint
                    <?php
                                            $dash_opem = "SELECT * FROM complain WHERE status='2'";
                                            $dash_open_run = mysqli_query($con, $dash_opem);

                                            if($topen = mysqli_num_rows($dash_open_run))
                                            {
                                                echo ' <h1 class="mb-0">'.$topen.'</h1>';
                                            }
                                            else
                                            {
                                                echo ' <h1 class="mb-0">0</h1>';
                                            }
                                        ?>
                    </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if(isset($_SESSION['auth_user']) && (isset($_SESSION['auth_role'])== '1')): ?>
                    <?php else:?>
        <!-- Report Now-->
<section class="page-section" id="report">
  <div class="container">
  <?php include('admin/admin/message.php'); ?>
    <div class="text-center">
                    <h2 class="section-heading text-uppercase">Report Now!</h2>
                </div>
    <form name ="report" id="RForm" action="" method="POST" enctype="multipart/form-data" >
     <div class="row align-items-stretch mb-5">
                        <div class="col-md-6">
                            <div class="form-group">
     <input type="text" name="FirstName" class="form-control" placeholder="First Name*" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required>
      						</div>
                            <div class="form-group">
     <input type="text" name="LastName" class="form-control" placeholder="Last Name*" minlength="2" pattern="^[a-zA-Z\s]+" title="Numbers are not allowed this field"  required/>
    						</div>
                            <div class="form-group"> 
     <input type="text" name="Email" class="form-control" placeholder="Email*" minlength="2" pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$" title = "Please input a valid email format eg. cauayan@isabela.com" required/>
      						</div>
                            <div class="form-group mb-md-0">
     <input type="text" name="Mobile" class="form-control" placeholder="Phone Number*" pattern="^[+]?[\d]+([\-][\d]+)*\d$" minlength="11" title="Must start with [09 / +63] and at least 11 digit number to 13 with area code" required/>
    					</div>
     </div>
     <div class="col-md-6">
                   <div class="form-group form-group-textarea mb-md-0">
     <textarea name="ComplaintDetails" class="form-control" placeholder="Complaint Details*" required></textarea>
      </div>             
                   <div class="form-group form-group-textarea mb-md-0">
                   <p>Please upload proof</p>
     <input type="file" name="CProof" value="" class="form-control"/>
    			   </div>
      			</div>
             </div>
             </br>
             </br>
             </br>
             </br></br>
            
     <input type="submit" name="btnreport" value="Report concern" class="btn btn-primary btn-xl w-100"/>
    </form>
  </div>  
</section>
 
<?php endif ?>

        <!-- Footer-->
        <footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 text-lg-start">Copyright &copy; PCMS|POSD <?php $year = date("Y"); echo $year;?></div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a class="link-dark text-decoration-none me-3" href="#!">Privacy Policy</a>
                        <a class="link-dark text-decoration-none" href="#!">Terms of Use</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Modals-->


         <!-- FAQS modal popup-->
         <?php
         $query = "SELECT * FROM faqs ORDER BY ID ASC";
         $query222 = mysqli_query($con, $query);
         ?>
        <div class="portfolio-modal modal fade" id="FAQs" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
					<div class="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                            
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
       
                    <div class="div modal fade" id="reg-modal1" tabindex="-1" aria-labelledby="modal-title" aria-hedden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modal-title">Complaint Proof</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <?php
                                if(isset($_GET['id']))
                                            {
                                                
                                                $CaseNo = $_GET['id'];
                                                $CDetails = "SELECT * FROM complain WHERE CaseNo='$CaseNo' ";
                                                $CDetails_run = mysqli_query($con, $CDetails);
                                                if(mysqli_num_rows($CDetails_run) > 0)
                                                {    
                                                    foreach($CDetails_run as $Details)
                                                    {
                                                ?>
                                                <img src="../../proof/<?=$Details['CProof'];?>" class="img-fluid">
                                                <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <h4>No record found</h4>
                                                    <?php
                                                }
                                            }
                                            ?>

                                </div>
                                <div class="div modal-footer">

                                </div>
                            </div>
                        </div>
                    </div>
                
                
               
                         <div class="div modal fade" id="infoModal" tabindex="-1" aria-labelledby="modal-title" aria-hedden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modal-title">Case History</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                </div>
                                <div class="div modal-footer">

                                </div>
                            </div>
                        </div>
                    </div>
               

              
                         <div class="div modal fade" id="faqmodals" tabindex="-1" aria-labelledby="modal-title" aria-hedden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title text-center" id="modal-title">FAQ's</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                </div>
                                <div class="div modal-footer">

                                </div>
                            </div>
                        </div>
                    </div>
                    

              
              <div class="div modal fade" id="ordimodal" tabindex="-1" aria-labelledby="modal-title" aria-hedden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modal-title">Municipal Ordinance</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                </div>
                                <div class="div modal-footer">

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="div modal fade" id="ordimodal" tabindex="-1" aria-labelledby="modal-title" aria-hedden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modal-title">Municipal Ordinance</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                </div>
                                <div class="div modal-footer">

                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="div modal fade" id="loginmodal" tabindex="-1" aria-labelledby="modal-title" aria-hedden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                </div>
                                <div class="div modal-footer">

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="div modal fade" id="signupmodal" tabindex="-1" aria-labelledby="modal-title" aria-hedden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                </div>
                                <div class="div modal-footer">

                                </div>
                            </div>
                        </div>
                    </div>
                    

         
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
<script type ="text/javascript">
	  
      $(document).ready(function(){
          $('.faqinfo').click(function(){
              $.ajax({
              url:"php/ajax3.php",
              success:function(response){
                  $('.modal-body').html(response);
                  $('#faqmodals').modal('show');
              
              }
              
          })
          })
          
      })

      
      $(document).ready(function(){
          $('.orinfo').click(function(){
              var userid = $(this).data('id');
              $.ajax({
              url:"php/ajax1.php",
              method:'post',
              data:{userid:userid},
              success:function(response){
                  $('.modal-body').html(response);
                  $('#ordimodal').modal('show');
              
              }
              
          })
          })
          
      }) 
      
      $(document).ready(function(){
          $('.logininfo').click(function(){
              $.ajax({
              url:"php/ajax2.php",
              success:function(response){
                  $('.modal-body').html(response);
                  $('#loginmodal').modal('show');
              
              }
              
          })
          })
          
      })

      $(document).ready(function(){
          $('.signupinfo').click(function(){
              $.ajax({
              url:"php/ajax4.php",
              success:function(response){
                  $('.modal-body').html(response);
                  $('#signupmodal').modal('show');
              
              }
              
          })
          })
          
      })
      
      </script>
      

</body>
</html>